#!/usr/bin/env bash
#
# Offline verification — no Docker, no Postgres, no Node.
#
#   bash scripts/verify-offline.sh
#
# Runs the part of the suite that is pure by construction: the workflow
# engine and the schedule arithmetic. Needs Python 3.11+ and two packages.
#
# This is not a substitute for the full run. It is the subset that can execute
# anywhere, and it happens to cover the layer that matters most — the engine is
# where the approval rule actually lives (docs/AUDIT.md §2, layer 2), and it is
# pure precisely so it can be driven with no database, no HTTP, and no AI
# provider. If this fails, nothing downstream is worth running.
#
# Writes VERIFICATION_REPORT_OFFLINE.md.

set -uo pipefail

cd "$(dirname "$0")/.." || exit 1
REPO_ROOT="$PWD"
REPORT="VERIFICATION_REPORT_OFFLINE.md"

printf '\n\033[1m==> Environment\033[0m\n'
python3 --version || { echo "python3 not found"; exit 1; }

printf '\n\033[1m==> Installing test runner (2 packages)\033[0m\n'
python3 -m pip install --quiet --disable-pip-version-check pytest pytest-asyncio \
  || { echo "could not install pytest"; exit 1; }

export PYTHONPATH="$REPO_ROOT:$REPO_ROOT/apps/api"
export DEFAULT_AI_PROVIDER=mock
export PYTHONDONTWRITEBYTECODE=1

OFFLINE_TESTS=(
  "apps/api/tests/test_workflow_engine.py"
  "apps/api/tests/test_schedule.py"
)

printf '\n\033[1m==> Running offline suite\033[0m\n'
OUT=$(python3 -m pytest "${OFFLINE_TESTS[@]}" -q --tb=short -p no:cacheprovider 2>&1)
STATUS=$?
echo "$OUT"

SUMMARY=$(echo "$OUT" | tail -1)

{
  echo "# Verification report — offline subset"
  echo
  echo "- **Generated:** $(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  echo "- **Python:** $(python3 --version 2>&1)"
  echo "- **Scope:** pure tests only — no database, no HTTP, no AI provider"
  echo
  if [ "$STATUS" -eq 0 ]; then
    echo "**Result: PASS** — \`$SUMMARY\`"
  else
    echo "**Result: FAIL** — \`$SUMMARY\`"
  fi
  echo
  echo "## What ran"
  echo
  echo "| Suite | Covers |"
  echo "|---|---|"
  echo "| \`test_workflow_engine.py\` | The approval gate itself: effects never execute unapproved, rejection halts, resume does not re-run completed steps, handler failure is recorded not swallowed |"
  echo "| \`test_schedule.py\` | Cadence parsing and next-slot arithmetic: boundary equality, month/year/leap rollover, UTC-not-local-time |"
  echo
  echo "## What did NOT run"
  echo
  echo "Everything requiring PostgreSQL 16 + pgvector — the API integration"
  echo "suite, the dispatcher and orphan-sweep tests, migrations, lint, and the"
  echo "frontend. Several of those exist specifically to check unique-index and"
  echo "constraint behaviour that only a real Postgres enforces, so they cannot"
  echo "be mocked without deleting the thing under test."
  echo
  echo "A passing report here means the core rule holds in isolation. It does"
  echo "not mean the build is verified. Run \`docker compose -f"
  echo "docker-compose.verify.yml up --abort-on-container-exit\` for that."
} > "$REPORT"

printf '\n\033[1m==> Wrote %s\033[0m\n' "$REPORT"
exit "$STATUS"
