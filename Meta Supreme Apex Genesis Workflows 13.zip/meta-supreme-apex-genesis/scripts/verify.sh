#!/usr/bin/env bash
#
# One-command verification. Produces VERIFICATION_REPORT.md.
#
# Runs inside the container defined by docker-compose.verify.yml, or on a
# machine with Python 3.11 + a reachable Postgres.
#
# Every stage is recorded whether it passes or fails, and the script does not
# stop at the first failure: an audit wants the full picture, not the first
# thing that broke. The exit code is nonzero if any stage failed.

set -uo pipefail

REPORT="VERIFICATION_REPORT.md"
FAILED=0
declare -a RESULTS

log()  { printf '\n\033[1m==> %s\033[0m\n' "$1"; }
record() { RESULTS+=("$1|$2|$3"); }

run_stage() {
  local name="$1"; shift
  local required="$1"; shift
  log "$name"
  local out
  if out=$("$@" 2>&1); then
    echo "$out" | tail -25
    record "$name" "PASS" "$(echo "$out" | tail -3 | tr '\n' ' ')"
  else
    echo "$out" | tail -40
    record "$name" "FAIL" "$(echo "$out" | tail -3 | tr '\n' ' ')"
    [ "$required" = "required" ] && FAILED=1
  fi
}

log "Environment"
python --version
echo "DATABASE_URL=${DATABASE_URL%%:*}://…"   # scheme only; never log credentials

log "Installing dependencies"
pip install --quiet --no-cache-dir -r apps/api/requirements.txt \
  && pip install --quiet --no-cache-dir ruff pytest pytest-asyncio httpx asyncpg alembic \
  || { echo "dependency install failed"; exit 1; }

# Migrations run against the app database. The test database is built
# separately by conftest from database/schemas/*.sql — that split is
# deliberate and documented in phase5-workflows/README.md.
run_stage "Migrations (alembic upgrade head)" required alembic upgrade head

run_stage "Backend tests" required \
  python -m pytest apps/api/tests -q --tb=short

run_stage "Lint (ruff)" required ruff check .

# Frontend stages are optional in the container image (no Node); they run when
# the harness is invoked on a machine that has pnpm.
if command -v pnpm >/dev/null 2>&1; then
  run_stage "Typecheck (tsc)" required \
    pnpm --filter @meta-supreme/web exec tsc --noEmit
  run_stage "Frontend build" required \
    pnpm --filter @meta-supreme/web build
else
  record "Typecheck (tsc)" "SKIPPED" "pnpm not present in this image"
  record "Frontend build" "SKIPPED" "pnpm not present in this image"
fi

log "Writing $REPORT"
{
  echo "# Verification report"
  echo
  echo "- **Generated:** $(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  echo "- **Commit:** $(git rev-parse --short HEAD 2>/dev/null || echo 'not a git checkout')"
  echo "- **Python:** $(python --version 2>&1)"
  echo "- **Provider mode:** ${DEFAULT_AI_PROVIDER:-unset} (no external API calls)"
  echo
  echo "| Stage | Result | Tail |"
  echo "|---|---|---|"
  for row in "${RESULTS[@]}"; do
    IFS='|' read -r name result tail <<< "$row"
    printf '| %s | **%s** | `%s` |\n' "$name" "$result" "${tail:0:110}"
  done
  echo
  if [ "$FAILED" -eq 0 ]; then
    echo "All required stages passed."
  else
    echo "**One or more required stages failed.** This build is not verified."
  fi
  echo
  echo "## What this does and does not prove"
  echo
  echo "Proves: the suite passes against a real PostgreSQL 16 + pgvector,"
  echo "migrations apply to an empty database, and the code lints."
  echo
  echo "Does not prove: behaviour against a live AI provider (these runs use the"
  echo "deterministic mock), performance under load, or security properties."
  echo "See docs/AUDIT.md for scope."
} > "$REPORT"

cat "$REPORT"
exit "$FAILED"
