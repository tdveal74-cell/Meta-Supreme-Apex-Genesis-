"""
Workflow layer — definitions and the execution engine.

Framework-free: standard library only. The engine executes a validated
`WorkflowDefinition` against injected step handlers, and stops at any step
that produces a side effect until a human approves it. Nothing here knows
about FastAPI, SQLAlchemy, or HTTP — the app layer supplies the handlers
and owns persistence.
"""

from services.workflows.definition import (
    DEFINITION_VERSION,
    EFFECT_STEP_TYPES,
    MAX_STEPS,
    StepType,
    TriggerType,
    WorkflowDefinition,
    WorkflowDefinitionError,
    WorkflowStep,
    WorkflowTrigger,
    render_template,
)
from services.workflows.engine import (
    RunOutcome,
    RunStatus,
    StepContext,
    StepOutput,
    StepResult,
    StepStatus,
    WorkflowEngine,
)

__all__ = [
    "DEFINITION_VERSION",
    "EFFECT_STEP_TYPES",
    "MAX_STEPS",
    "RunOutcome",
    "RunStatus",
    "StepContext",
    "StepOutput",
    "StepResult",
    "StepStatus",
    "StepType",
    "TriggerType",
    "WorkflowDefinition",
    "WorkflowDefinitionError",
    "WorkflowEngine",
    "WorkflowStep",
    "WorkflowTrigger",
    "render_template",
]
