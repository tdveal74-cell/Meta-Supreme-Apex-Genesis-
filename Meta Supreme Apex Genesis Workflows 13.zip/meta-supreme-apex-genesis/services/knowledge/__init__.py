"""Knowledge engine — chunking and retrieval primitives (framework-free)."""

from services.knowledge.chunking import (
    DEFAULT_CHUNK_CHARS,
    DEFAULT_OVERLAP_CHARS,
    Chunk,
    chunk_text,
)

__all__ = [
    "Chunk",
    "DEFAULT_CHUNK_CHARS",
    "DEFAULT_OVERLAP_CHARS",
    "chunk_text",
]
