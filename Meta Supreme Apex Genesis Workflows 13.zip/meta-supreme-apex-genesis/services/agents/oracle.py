"""Oracle agent — see registry.py for the canonical definition."""

from .registry import ORACLE, get_agent

__all__ = ["ORACLE", "get_agent"]
