# AI Council — Agent Framework

This package contains the specialized intelligence agents that form the Council.

## Agents

| Agent      | Purpose                          | Status    |
|------------|----------------------------------|-----------|
| Oracle     | Future intelligence              | Scaffold  |
| Analyst    | Evidence & research              | Scaffold  |
| Strategist | Decision intelligence            | Scaffold  |
| Architect  | Systems intelligence             | Planned   |
| Engineer   | Execution intelligence           | Planned   |
| Guardian   | Risk intelligence                | Planned   |
| Creator    | Communication intelligence       | Planned   |
| Librarian  | Knowledge intelligence           | Planned   |
| Skeptic    | Challenge intelligence           | Planned   |

## Agent Contract

Every agent must implement:

- **Identity**
- **Mission**
- **System Instructions**
- **Capabilities**
- **Limitations**
- **Output Format**
- **Evaluation Criteria**
- **Version History**

See `registry.py` for the agent registry and configuration system.
