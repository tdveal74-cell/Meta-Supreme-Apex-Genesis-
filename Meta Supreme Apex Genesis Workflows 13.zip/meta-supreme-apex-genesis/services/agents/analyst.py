"""Analyst agent — see registry.py for the canonical definition."""

from .registry import ANALYST, get_agent

__all__ = ["ANALYST", "get_agent"]
