"""Intelligence core — Executive Controller, synthesis, and AI providers.

Exports are resolved lazily (PEP 562) so that submodules — which import
from `services.agents` and `services.intelligence.providers` — never
re-enter this package init while it is still initializing.
"""

from typing import TYPE_CHECKING

_CONTROLLER_EXPORTS = {
    "AgentContribution",
    "ContextPacket",
    "CouncilExecutionError",
    "ExecutiveController",
    "IntentCategory",
    "SynthesisResult",
}
_SYNTHESIZER_EXPORTS = {"Synthesizer", "SynthesisOutput"}

__all__ = sorted(_CONTROLLER_EXPORTS | _SYNTHESIZER_EXPORTS)

if TYPE_CHECKING:  # static analyzers see the real symbols
    from services.intelligence.executive_controller import (  # noqa: F401
        AgentContribution,
        ContextPacket,
        CouncilExecutionError,
        ExecutiveController,
        IntentCategory,
        SynthesisResult,
    )
    from services.intelligence.synthesizer import (  # noqa: F401
        SynthesisOutput,
        Synthesizer,
    )


def __getattr__(name: str):
    if name in _CONTROLLER_EXPORTS:
        from services.intelligence import executive_controller as module
        return getattr(module, name)
    if name in _SYNTHESIZER_EXPORTS:
        from services.intelligence import synthesizer as module
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
