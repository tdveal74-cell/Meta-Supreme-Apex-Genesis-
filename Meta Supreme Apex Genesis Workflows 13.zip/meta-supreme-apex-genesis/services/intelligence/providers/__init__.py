"""AI provider abstraction — model-agnostic completion + embedding interfaces."""

from services.intelligence.providers.anthropic_provider import AnthropicProvider
from services.intelligence.providers.base import (
    AIProvider,
    ChatMessage,
    CompletionRequest,
    CompletionResponse,
    ProviderAuthError,
    ProviderConfigError,
    ProviderError,
    ProviderRateLimitError,
    ProviderResponseError,
    ProviderServerError,
    ProviderTimeoutError,
    TokenUsage,
    extract_json,
)
from services.intelligence.providers.embeddings import (
    EMBEDDING_DIMENSIONS,
    SUPPORTED_EMBEDDING_PROVIDERS,
    EmbeddingProvider,
    EmbeddingResponse,
    MockEmbeddingProvider,
    OpenAIEmbeddingProvider,
    create_embedding_provider,
)
from services.intelligence.providers.factory import SUPPORTED_PROVIDERS, create_provider
from services.intelligence.providers.mock_provider import REQUIRED_KEYS_MARKER, MockProvider
from services.intelligence.providers.openai_provider import OpenAIProvider

__all__ = [
    "AIProvider",
    "AnthropicProvider",
    "ChatMessage",
    "CompletionRequest",
    "CompletionResponse",
    "EMBEDDING_DIMENSIONS",
    "EmbeddingProvider",
    "EmbeddingResponse",
    "MockEmbeddingProvider",
    "MockProvider",
    "OpenAIEmbeddingProvider",
    "OpenAIProvider",
    "ProviderAuthError",
    "ProviderConfigError",
    "ProviderError",
    "ProviderRateLimitError",
    "ProviderResponseError",
    "ProviderServerError",
    "ProviderTimeoutError",
    "REQUIRED_KEYS_MARKER",
    "SUPPORTED_EMBEDDING_PROVIDERS",
    "SUPPORTED_PROVIDERS",
    "TokenUsage",
    "create_embedding_provider",
    "create_provider",
    "extract_json",
]
