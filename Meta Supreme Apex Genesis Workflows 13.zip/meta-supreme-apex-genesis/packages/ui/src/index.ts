/**
 * @meta-supreme/ui
 * Shared UI primitives for Meta Supreme Apex Genesis.
 * Currently the design system lives in apps/web/components.
 * This package is the future home for truly shared, framework-agnostic or cross-app components.
 */

export {};
