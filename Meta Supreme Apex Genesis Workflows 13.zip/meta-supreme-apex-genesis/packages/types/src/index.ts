/**
 * @meta-supreme/types
 * Shared TypeScript types across frontend and (via codegen) backend contracts.
 */

export type Plan = "free" | "professional" | "enterprise";

export type AgentSlug =
  | "oracle"
  | "analyst"
  | "strategist"
  | "architect"
  | "engineer"
  | "guardian"
  | "creator"
  | "librarian"
  | "skeptic";

export interface User {
  id: string;
  email: string;
  full_name: string | null;
  is_verified?: boolean;
  created_at?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string | null;
  status: "active" | "archived" | "deleted";
  organization_id: string | null;
  owner_id: string;
  created_at: string;
  updated_at: string;
}

export interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}
