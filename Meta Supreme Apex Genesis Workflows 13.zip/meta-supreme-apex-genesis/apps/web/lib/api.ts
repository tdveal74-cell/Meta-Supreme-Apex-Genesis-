/**
 * Typed API client for Meta Supreme Apex Genesis.
 * Phase 2: auth, conversations, and the Intelligence (Council) API.
 */

const API_BASE =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, "") || "http://localhost:8000";

type RequestOptions = {
  method?: string;
  body?: unknown;
  token?: string | null;
  headers?: Record<string, string>;
};

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export async function api<T = unknown>(
  path: string,
  options: RequestOptions = {}
): Promise<T> {
  const { method = "GET", body, token, headers = {} } = options;

  const res = await fetch(`${API_BASE}/api/v1${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({}));
    const message =
      errorBody?.error?.message || errorBody?.detail || res.statusText;
    throw new ApiError(
      message || `Request failed with status ${res.status}`,
      res.status
    );
  }

  // 204 No Content
  if (res.status === 204) {
    return undefined as T;
  }

  return res.json() as Promise<T>;
}

/* ------------------------------------------------------------------------ */
/* Types                                                                     */
/* ------------------------------------------------------------------------ */

export interface User {
  id: string;
  email: string;
  full_name: string | null;
  is_verified: boolean;
  created_at: string | null;
}

export interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

export interface Project {
  id: string;
  name: string;
  description: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface AgentSummary {
  slug: string;
  name: string;
  purpose: string;
  mission: string;
  version: string;
  is_active: boolean;
}

export interface Conversation {
  id: string;
  title: string | null;
  status: string;
  project_id: string | null;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface KnowledgeSourceRef {
  knowledge_item_id: string;
  title: string;
  chunk_index: number;
  distance: number;
}

export interface MessageMeta {
  request_id?: string;
  intent?: string;
  intent_source?: string;
  agents_consulted?: string[];
  recommended_actions?: string[];
  points_of_agreement?: string[];
  points_of_tension?: string[];
  confidence?: number;
  synthesis_mode?: string;
  deliberation_rounds?: number;
  provider?: string;
  model?: string;
  total_input_tokens?: number;
  total_output_tokens?: number;
  total_latency_ms?: number;
  knowledge_sources?: KnowledgeSourceRef[];
  memories_recalled?: number;
}

export interface Message {
  id: string;
  conversation_id: string;
  role: "user" | "assistant" | "system" | "agent";
  content: string;
  metadata: MessageMeta;
  token_count: number | null;
  created_at: string;
}

export interface ConversationDetail extends Conversation {
  messages: Message[];
}

export interface Contribution {
  agent_slug: string;
  agent_name: string;
  status: "completed" | "failed";
  content: Record<string, unknown> | null;
  confidence: number;
  latency_ms: number;
  input_tokens: number;
  output_tokens: number;
  error: string | null;
  round: number;
}

export interface CouncilResponse {
  request_id: string;
  conversation_id: string;
  user_message: Message;
  assistant_message: Message;
  intent: string;
  intent_source: string;
  agents_consulted: string[];
  contributions: Contribution[];
  recommended_actions: string[];
  points_of_agreement: string[];
  points_of_tension: string[];
  confidence: number;
  synthesis_mode: string;
  deliberation_rounds: number;
  provider: string;
  model: string;
  total_input_tokens: number;
  total_output_tokens: number;
  total_latency_ms: number;
}

/** Live progress event from the streaming Council endpoint. */
export type CouncilEvent =
  | { type: "run_started"; request_id: string }
  | { type: "context"; knowledge_retrieved: number; memories_recalled: number }
  | { type: "intent"; intent: string; source: string }
  | { type: "agents_selected"; agents: string[]; rounds: number }
  | { type: "agent_started"; agent: string; round: number }
  | {
      type: "agent_completed";
      agent: string;
      round: number;
      status: "completed" | "failed";
      confidence: number;
      latency_ms: number;
    }
  | { type: "synthesis_started" }
  | { type: "complete"; payload: CouncilResponse }
  | { type: "error"; status: number; message: string };

export interface IntelligenceStatus {
  provider: string;
  model: string;
  simulated: boolean;
  parallel_execution: boolean;
  agents_available: number;
}

/* ------------------------------------------------------------------------ */
/* Endpoint groups                                                           */
/* ------------------------------------------------------------------------ */

export const authApi = {
  register: (data: { email: string; password: string; full_name?: string }) =>
    api<User>("/auth/register", { method: "POST", body: data }),
  login: (data: { email: string; password: string }) =>
    api<TokenResponse>("/auth/login", { method: "POST", body: data }),
  me: (token: string) => api<User>("/auth/me", { token }),
};

export const projectsApi = {
  list: (token: string) => api<Project[]>("/projects", { token }),
  create: (token: string, data: { name: string; description?: string }) =>
    api<Project>("/projects", { method: "POST", body: data, token }),
};

export const agentsApi = {
  list: (token: string) => api<AgentSummary[]>("/agents", { token }),
};

export const conversationsApi = {
  list: (token: string) => api<Conversation[]>("/conversations", { token }),
  create: (token: string, data: { title?: string; project_id?: string } = {}) =>
    api<Conversation>("/conversations", { method: "POST", body: data, token }),
  get: (token: string, id: string) =>
    api<ConversationDetail>(`/conversations/${id}`, { token }),
  sendMessage: (
    token: string,
    id: string,
    data: {
      content: string;
      agents?: string[];
      full_council?: boolean;
      deliberate?: boolean;
    }
  ) =>
    api<CouncilResponse>(`/conversations/${id}/messages`, {
      method: "POST",
      body: data,
      token,
    }),

  /**
   * Streaming variant: consumes Server-Sent Events and invokes `onEvent`
   * for each one, resolving with the final CouncilResponse. Throws on a
   * terminal error event or transport failure — callers can fall back to
   * the non-streaming endpoint.
   */
  sendMessageStream: async (
    token: string,
    id: string,
    data: {
      content: string;
      agents?: string[];
      full_council?: boolean;
      deliberate?: boolean;
    },
    onEvent: (event: CouncilEvent) => void
  ): Promise<CouncilResponse> => {
    const res = await fetch(`${API_BASE}/api/v1/conversations/${id}/messages/stream`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });
    if (!res.ok || !res.body) {
      const errorBody = await res.json().catch(() => ({}));
      throw new ApiError(
        errorBody?.error?.message || errorBody?.detail || res.statusText,
        res.status
      );
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let complete: CouncilResponse | null = null;

    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let boundary = buffer.indexOf("\n\n");
      while (boundary !== -1) {
        const block = buffer.slice(0, boundary).trim();
        buffer = buffer.slice(boundary + 2);
        boundary = buffer.indexOf("\n\n");
        if (!block.startsWith("data: ")) continue;

        const event = JSON.parse(block.slice(6)) as CouncilEvent;
        onEvent(event);
        if (event.type === "complete") complete = event.payload;
        if (event.type === "error") {
          throw new ApiError(event.message, event.status);
        }
      }
    }

    if (!complete) {
      throw new ApiError("Stream ended without a complete event", 502);
    }
    return complete;
  },
};

export const intelligenceApi = {
  status: (token: string) => api<IntelligenceStatus>("/intelligence/status", { token }),
  ask: (
    token: string,
    data: { message: string; agents?: string[]; full_council?: boolean }
  ) => api("/intelligence/ask", { method: "POST", body: data, token }),
};

/* ------------------------------------------------------------------------ */
/* Knowledge                                                                 */
/* ------------------------------------------------------------------------ */

export interface KnowledgeItem {
  id: string;
  title: string;
  source_type: string;
  source_uri: string | null;
  status: "processing" | "ready" | "failed" | "archived";
  project_id: string | null;
  chunk_count: number;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface KnowledgeSearchHit {
  knowledge_item_id: string;
  title: string;
  source_type: string;
  chunk_index: number;
  content: string;
  distance: number;
}

export const knowledgeApi = {
  list: (token: string) => api<KnowledgeItem[]>("/knowledge", { token }),
  create: (
    token: string,
    data: {
      title: string;
      content: string;
      source_type?: string;
      source_uri?: string;
      project_id?: string;
    }
  ) => api<KnowledgeItem>("/knowledge", { method: "POST", body: data, token }),
  search: (token: string, data: { query: string; limit?: number }) =>
    api<KnowledgeSearchHit[]>("/knowledge/search", {
      method: "POST",
      body: data,
      token,
    }),
  remove: (token: string, id: string) =>
    api<void>(`/knowledge/${id}`, { method: "DELETE", token }),
};

/* ------------------------------------------------------------------------ */
/* Memory                                                                    */
/* ------------------------------------------------------------------------ */

export interface Memory {
  id: string;
  memory_type: string;
  content: string;
  importance: number;
  is_active: boolean;
  project_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export const memoryApi = {
  list: (token: string) => api<Memory[]>("/memory", { token }),
  create: (
    token: string,
    data: { content: string; memory_type?: string; importance?: number }
  ) => api<Memory>("/memory", { method: "POST", body: data, token }),
  update: (
    token: string,
    id: string,
    data: {
      content?: string;
      memory_type?: string;
      importance?: number;
      is_active?: boolean;
    }
  ) => api<Memory>(`/memory/${id}`, { method: "PATCH", body: data, token }),
  remove: (token: string, id: string) =>
    api<void>(`/memory/${id}`, { method: "DELETE", token }),
};

/* ------------------------------------------------------------------------ */
/* Decisions                                                                 */
/* ------------------------------------------------------------------------ */

export interface Decision {
  id: string;
  question: string;
  options: string[];
  recommendation: string | null;
  chosen_option: string | null;
  outcome: string | null;
  outcome_notes: string | null;
  status: "open" | "decided" | "reviewed" | "archived";
  project_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export const decisionsApi = {
  list: (token: string) => api<Decision[]>("/decisions", { token }),
  create: (
    token: string,
    data: { question: string; options?: string[]; recommendation?: string }
  ) => api<Decision>("/decisions", { method: "POST", body: data, token }),
  fromMessage: (token: string, messageId: string) =>
    api<Decision>("/decisions/from-message", {
      method: "POST",
      body: { message_id: messageId },
      token,
    }),
  update: (
    token: string,
    id: string,
    data: {
      chosen_option?: string;
      outcome?: string;
      outcome_notes?: string;
      status?: string;
    }
  ) => api<Decision>(`/decisions/${id}`, { method: "PATCH", body: data, token }),
};

/* ------------------------------------------------------------------------ */
/* Workflows (Phase 5)                                                       */
/* ------------------------------------------------------------------------ */

export type WorkflowStepType =
  | "knowledge_search"
  | "council"
  | "memory_write"
  | "decision_draft"
  | "export";

export type WorkflowTriggerType = "manual" | "schedule" | "event";

export type WorkflowStatus = "draft" | "active" | "paused" | "archived";

export type WorkflowRunStatus =
  | "pending"
  | "running"
  | "awaiting_approval"
  | "completed"
  | "halted"
  | "failed";

export interface WorkflowStepDefinition {
  id: string;
  type: WorkflowStepType;
  config: Record<string, unknown>;
}

export interface WorkflowDefinition {
  version: number;
  trigger: { type: WorkflowTriggerType; config: Record<string, unknown> };
  steps: WorkflowStepDefinition[];
}

/** Server-computed facts about a stored definition — never recomputed client-side. */
export interface DefinitionSummary {
  valid: boolean;
  error: string | null;
  step_count: number;
  approval_steps: string[];
  trigger_type: WorkflowTriggerType | null;
  /**
   * True when the trigger is stored and valid but nothing dispatches it yet.
   * As of 5.1 only `event` qualifies — `schedule` is dispatched by cron.
   */
  awaiting_dispatcher: boolean;
}

export interface WorkflowRunSummary {
  id: string;
  status: WorkflowRunStatus;
  trigger: string;
  pending_step_id: string | null;
  total_tokens: number;
  started_at: string;
  completed_at: string | null;
}

export interface Workflow {
  id: string;
  name: string;
  description: string | null;
  definition: WorkflowDefinition | Record<string, never>;
  summary: DefinitionSummary;
  status: WorkflowStatus;
  project_id: string | null;
  run_count: number;
  last_run: WorkflowRunSummary | null;
  metadata: Record<string, unknown>;
  /** Set only for active workflows on a parseable cadence; UTC ISO string. */
  next_run_at: string | null;
  last_fired_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface WorkflowStepResult {
  step_id: string;
  step_type: WorkflowStepType;
  status: "completed" | "failed" | "rejected";
  summary: string;
  text: string;
  data: Record<string, unknown>;
  input_tokens: number;
  output_tokens: number;
  latency_ms: number;
  error: string | null;
}

/** The rendered payload the owner is being asked to allow. */
export interface PendingApproval {
  step_id: string;
  step_type: WorkflowStepType | null;
  preview: Record<string, unknown>;
}

export interface ApprovalRecord {
  decision: "approved" | "rejected";
  actor_id: string;
  at: string;
}

export interface WorkflowRun {
  id: string;
  workflow_id: string;
  workflow_name: string;
  status: WorkflowRunStatus;
  trigger: string;
  trigger_input: string | null;
  steps: WorkflowStepResult[];
  approvals: Record<string, ApprovalRecord>;
  pending: PendingApproval | null;
  token_usage: { input_tokens?: number; output_tokens?: number; total_tokens?: number };
  latency_ms: number;
  error_message: string | null;
  started_at: string;
  completed_at: string | null;
}

export interface WorkflowStepTypeInfo {
  type: WorkflowStepType;
  label: string;
  description: string;
  required_config: string;
  requires_approval: boolean;
}

export interface WorkflowCapabilities {
  step_types: WorkflowStepTypeInfo[];
  trigger_types: WorkflowTriggerType[];
  max_steps: number;
  approval_required: boolean;
  dispatchable_triggers: WorkflowTriggerType[];
}

export const workflowsApi = {
  /**
   * The step catalog, including which steps stop for approval. The builder
   * reads this rather than hard-coding the list, so approval semantics have
   * exactly one source of truth — the services layer.
   */
  capabilities: (token: string) =>
    api<WorkflowCapabilities>("/workflows/step-types", { token }),
  list: (token: string, page: { limit?: number; offset?: number } = {}) =>
    api<Workflow[]>(
      `/workflows?limit=${page.limit ?? 50}&offset=${page.offset ?? 0}`,
      { token }
    ),
  get: (token: string, id: string) => api<Workflow>(`/workflows/${id}`, { token }),
  create: (
    token: string,
    data: {
      name: string;
      description?: string;
      definition: WorkflowDefinition;
      project_id?: string;
    }
  ) => api<Workflow>("/workflows", { method: "POST", body: data, token }),
  update: (
    token: string,
    id: string,
    data: {
      name?: string;
      description?: string;
      definition?: WorkflowDefinition;
      status?: WorkflowStatus;
    }
  ) => api<Workflow>(`/workflows/${id}`, { method: "PATCH", body: data, token }),
  remove: (token: string, id: string) =>
    api<void>(`/workflows/${id}`, { method: "DELETE", token }),

  /**
   * Starts a run and returns it already advanced to its first gate.
   *
   * Pass `idempotencyKey` and hold it across retries: the server returns the
   * original run (200) instead of starting a second one. Callers that drop
   * the key on a failed attempt lose the guarantee — reuse it until the call
   * actually succeeds.
   */
  run: (token: string, id: string, input = "", idempotencyKey?: string) =>
    api<WorkflowRun>(`/workflows/${id}/runs`, {
      method: "POST",
      body: { input },
      token,
      headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {},
    }),
  runs: (token: string, id: string, page: { limit?: number; offset?: number } = {}) =>
    api<WorkflowRun[]>(
      `/workflows/${id}/runs?limit=${page.limit ?? 50}&offset=${page.offset ?? 0}`,
      { token }
    ),
  getRun: (token: string, workflowId: string, runId: string) =>
    api<WorkflowRun>(`/workflows/${workflowId}/runs/${runId}`, { token }),

  /** `{ [stepId]: "approved" | "rejected" }` — the pending step must be present. */
  approve: (
    token: string,
    workflowId: string,
    runId: string,
    decisions: Record<string, "approved" | "rejected">
  ) =>
    api<WorkflowRun>(`/workflows/${workflowId}/runs/${runId}/approve`, {
      method: "POST",
      body: { decisions },
      token,
    }),
};
