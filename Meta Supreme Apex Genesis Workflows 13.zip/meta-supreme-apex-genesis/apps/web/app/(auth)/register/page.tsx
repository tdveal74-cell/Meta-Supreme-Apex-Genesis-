"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";

import { useAuth } from "@/lib/auth-context";

export default function RegisterPage() {
  const { register, token, loading: sessionLoading } = useAuth();
  const router = useRouter();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!sessionLoading && token) {
      router.replace("/dashboard");
    }
  }, [sessionLoading, token, router]);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await register(email, password, fullName.trim() || undefined);
      router.replace("/dashboard");
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Registration failed. Try again."
      );
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* Left panel */}
      <div className="hidden w-1/2 bg-navy lg:flex lg:flex-col lg:justify-between lg:p-12">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber/20">
            <span className="text-sm font-bold text-amber">MS</span>
          </div>
          <span className="text-lg font-semibold text-surface">Meta Supreme</span>
        </div>
        <div>
          <h2 className="text-3xl font-semibold tracking-tight text-surface">
            Begin with clarity.
          </h2>
          <p className="mt-4 max-w-md text-surface/70">
            Create your account to access the Command Center, AI Council, Knowledge
            Vault, and Decision Center.
          </p>
        </div>
        <p className="text-sm text-surface/40">
          Secure by design · Transparent by default
        </p>
      </div>

      {/* Right panel — form */}
      <div className="flex w-full flex-col justify-center px-6 py-12 lg:w-1/2 lg:px-16">
        <div className="mx-auto w-full max-w-sm">
          <div className="mb-8 lg:hidden">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy">
                <span className="text-sm font-bold text-amber">MS</span>
              </div>
              <span className="text-lg font-semibold text-navy">Meta Supreme</span>
            </div>
          </div>

          <h1 className="text-2xl font-semibold tracking-tight text-navy">
            Create account
          </h1>
          <p className="mt-2 text-sm text-navy/60">
            Start building your intelligence operating system.
          </p>

          <form className="mt-8 space-y-5" onSubmit={handleSubmit}>
            <div>
              <label
                htmlFor="full_name"
                className="block text-sm font-medium text-navy"
              >
                Full name
              </label>
              <input
                id="full_name"
                name="full_name"
                type="text"
                autoComplete="name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="mt-1.5 block w-full rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy shadow-sm placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20"
                placeholder="Alex Rivera"
              />
            </div>

            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-navy"
              >
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1.5 block w-full rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy shadow-sm placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20"
                placeholder="you@organization.com"
              />
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-navy"
              >
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="new-password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1.5 block w-full rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy shadow-sm placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20"
                placeholder="Minimum 8 characters"
              />
            </div>

            {error && (
              <p
                role="alert"
                className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700"
              >
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-lg bg-navy px-4 py-2.5 text-sm font-medium text-surface shadow-soft transition hover:bg-navy-800 focus:outline-none focus:ring-2 focus:ring-navy focus:ring-offset-2 disabled:opacity-60"
            >
              {submitting ? "Creating account…" : "Create account"}
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-navy/60">
            Already have an account?{" "}
            <Link
              href="/login"
              className="font-medium text-amber hover:text-amber-600"
            >
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
