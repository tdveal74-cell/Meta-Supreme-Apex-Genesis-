"use client";

/**
 * Workflows — automations that put the Council to work.
 *
 * The screen is organised around the one rule that makes automation safe
 * here: steps that read run unattended; steps that write memory, open a
 * decision, or prepare an export stop and wait for you. Which steps those
 * are is not decided in this file — it comes from `/workflows/step-types`,
 * so the badge on a step and the behaviour of the engine can never disagree.
 */

import {
  AlertTriangle,
  BookOpen,
  Brain,
  Check,
  Clock,
  FileText,
  Loader2,
  Play,
  Plus,
  Scale,
  ShieldAlert,
  Users,
  X,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentType,
  type ReactNode,
} from "react";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  workflowsApi,
  type Workflow,
  type WorkflowCapabilities,
  type WorkflowDefinition,
  type WorkflowRun,
  type WorkflowRunStatus,
  type WorkflowStepDefinition,
  type WorkflowStepType,
} from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

const STEP_ICONS: Record<WorkflowStepType, ComponentType<{ className?: string }>> = {
  knowledge_search: BookOpen,
  council: Users,
  memory_write: Brain,
  decision_draft: Scale,
  export: FileText,
};

const RUN_STATUS_STYLES: Record<WorkflowRunStatus, string> = {
  pending: "bg-surface-muted text-navy/60",
  running: "bg-navy/10 text-navy",
  awaiting_approval: "bg-amber-50 text-amber-700",
  completed: "bg-emerald-50 text-emerald-700",
  halted: "bg-red-50 text-red-700",
  failed: "bg-red-50 text-red-700",
};

const RUN_STATUS_LABELS: Record<WorkflowRunStatus, string> = {
  pending: "pending",
  running: "running",
  awaiting_approval: "waiting on you",
  completed: "completed",
  halted: "halted by you",
  failed: "failed",
};

/** Starter definitions — valid on the server as written, not illustrations. */
const TEMPLATES: { name: string; description: string; definition: WorkflowDefinition }[] =
  [
    {
      name: "New knowledge → risk scan",
      description:
        "Reads what you already know, asks the Council what the new material puts at risk, then offers to remember the finding.",
      definition: {
        version: 1,
        trigger: { type: "manual", config: {} },
        steps: [
          {
            id: "recall",
            type: "knowledge_search",
            config: { query: "{{ input }}", limit: 6 },
          },
          {
            id: "assess",
            type: "council",
            config: {
              prompt:
                "New material: {{ input }}\n\nPrior material from the vault:\n{{ recall }}\n\nWhat exposure does this create that our risk register does not already name?",
              deliberate: true,
            },
          },
          {
            id: "remember",
            type: "memory_write",
            config: { content: "{{ assess }}", importance: 7, memory_type: "context" },
          },
        ],
      },
    },
    {
      name: "Weekly strategic brief",
      description:
        "A standing question to the full Council, rendered into a brief you can read and copy.",
      definition: {
        version: 1,
        trigger: { type: "schedule", config: { cadence: "weekly:mon:07:00" } },
        steps: [
          {
            id: "brief",
            type: "council",
            config: {
              prompt:
                "Given everything in the vault, what are the three things most worth my attention this week, and what would change my mind about each?",
              full_council: true,
              deliberate: true,
            },
          },
          {
            id: "render",
            type: "export",
            config: { title: "Weekly strategic brief", body: "{{ brief }}" },
          },
        ],
      },
    },
  ];

function shortTime(value: string) {
  return new Date(value).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function tokens(n: number | undefined) {
  if (!n) return "—";
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
}

function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <p className="text-[11px] font-semibold uppercase tracking-wide text-navy/40">
      {children}
    </p>
  );
}

function RunStatusPill({ status }: { status: WorkflowRunStatus }) {
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${RUN_STATUS_STYLES[status]}`}
    >
      {RUN_STATUS_LABELS[status]}
    </span>
  );
}

/* ------------------------------------------------------------------------ */

function StepRow({
  step,
  isLast,
  gated,
  label,
  result,
}: {
  step: WorkflowStepDefinition;
  isLast: boolean;
  gated: boolean;
  label: string;
  result?: WorkflowRun["steps"][number];
}) {
  const Icon = STEP_ICONS[step.type] ?? BookOpen;
  const detail =
    (step.config.query as string) ??
    (step.config.prompt as string) ??
    (step.config.content as string) ??
    (step.config.question as string) ??
    (step.config.title as string) ??
    "";

  return (
    <li className="flex gap-3 py-3">
      <div className="flex flex-col items-center">
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-surface-muted">
          <Icon className="h-3.5 w-3.5 text-navy/60" />
        </span>
        {!isLast && <span className="mt-1 w-px flex-1 bg-border" aria-hidden />}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium text-navy">{label}</span>
          <code className="rounded bg-surface-muted px-1 text-[11px] text-navy/50">
            {step.id}
          </code>
          {gated && (
            <span className="inline-flex items-center gap-1 rounded-full border border-amber-300 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-amber-700">
              <ShieldAlert className="h-3 w-3" />
              approval
            </span>
          )}
          {result && (
            <span className="text-[11px] text-navy/40">
              {result.status} · {result.latency_ms}ms ·{" "}
              {tokens(result.input_tokens + result.output_tokens)} tokens
            </span>
          )}
        </div>
        <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed text-navy/60">
          {detail}
        </p>
      </div>
    </li>
  );
}

/* ------------------------------------------------------------------------ */

function ApprovalGate({
  run,
  busy,
  onDecide,
}: {
  run: WorkflowRun;
  busy: boolean;
  onDecide: (decision: "approved" | "rejected") => void;
}) {
  const pending = run.pending;
  if (!pending) return null;

  const entries = Object.entries(pending.preview).filter(
    ([, value]) => value !== null && value !== undefined && value !== ""
  );

  return (
    <Card
      className="border-amber-300 bg-amber-50/40"
      aria-live="polite"
      aria-label="Approval required"
    >
      <div className="p-5">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-4 w-4 text-amber-600" />
          <Eyebrow>Waiting on you</Eyebrow>
        </div>
        <h3 className="mt-1.5 text-base font-semibold text-navy">
          {pending.step_type === "memory_write"
            ? "Approve a memory write"
            : pending.step_type === "decision_draft"
              ? "Approve opening a decision"
              : pending.step_type === "export"
                ? "Approve preparing this export"
                : "Approve this step"}
        </h3>
        <p className="mt-1 max-w-prose text-sm leading-relaxed text-navy/70">
          This is exactly what would be written — not the template that produced
          it. Nothing happens until you decide, and the run keeps your decision
          either way.
        </p>

        <dl className="mt-4 space-y-3 rounded-lg border border-amber-200 bg-surface-elevated p-4">
          {entries.map(([key, value]) => (
            <div key={key}>
              <dt className="text-[11px] font-semibold uppercase tracking-wide text-navy/40">
                {key.replace(/_/g, " ")}
              </dt>
              <dd className="mt-0.5 whitespace-pre-wrap text-sm leading-relaxed text-navy/80">
                {typeof value === "string" ? value : JSON.stringify(value, null, 2)}
              </dd>
            </div>
          ))}
        </dl>

        <div className="mt-4 flex flex-wrap gap-2">
          <Button
            variant="accent"
            size="sm"
            disabled={busy}
            onClick={() => onDecide("approved")}
          >
            {busy ? (
              <Loader2 className="h-3.5 w-3.5 motion-safe:animate-spin" />
            ) : (
              <Check className="h-3.5 w-3.5" />
            )}
            Approve and continue
          </Button>
          <Button
            variant="outline"
            size="sm"
            disabled={busy}
            onClick={() => onDecide("rejected")}
          >
            <X className="h-3.5 w-3.5" />
            Reject and halt
          </Button>
        </div>
      </div>
    </Card>
  );
}

/* ------------------------------------------------------------------------ */

export default function WorkflowsPage() {
  const { token } = useAuth();

  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [capabilities, setCapabilities] = useState<WorkflowCapabilities | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [openRunId, setOpenRunId] = useState<string | null>(null);
  const [triggerInput, setTriggerInput] = useState("");

  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Held across retries, cleared only on success. A run that failed to reach
  // the server and one that succeeded but lost its response look identical
  // from here; reusing the key is what makes the retry safe either way.
  const runKey = useRef<string | null>(null);

  const selected = workflows.find((w) => w.id === selectedId) ?? null;
  const openRun = runs.find((r) => r.id === openRunId) ?? runs[0] ?? null;

  const stepLabels = useMemo(() => {
    const map = new Map<WorkflowStepType, string>();
    capabilities?.step_types.forEach((s) => map.set(s.type, s.label));
    return map;
  }, [capabilities]);

  const loadWorkflows = useCallback(
    async (preferId?: string) => {
      if (!token) return;
      const list = await workflowsApi.list(token);
      setWorkflows(list);
      setSelectedId((current) => preferId ?? current ?? list[0]?.id ?? null);
    },
    [token]
  );

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [list, caps] = await Promise.all([
          workflowsApi.list(token),
          workflowsApi.capabilities(token),
        ]);
        if (cancelled) return;
        setWorkflows(list);
        setCapabilities(caps);
        setSelectedId(list[0]?.id ?? null);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Could not load workflows");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  useEffect(() => {
    if (!token || !selectedId) {
      setRuns([]);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const history = await workflowsApi.runs(token, selectedId);
        if (cancelled) return;
        setRuns(history);
        setOpenRunId(history[0]?.id ?? null);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Could not load run history");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token, selectedId]);

  async function createFromTemplate(template: (typeof TEMPLATES)[number]) {
    if (!token) return;
    setBusy(true);
    setError(null);
    try {
      const created = await workflowsApi.create(token, {
        name: template.name,
        description: template.description,
        definition: template.definition,
      });
      await loadWorkflows(created.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create the workflow");
    } finally {
      setBusy(false);
    }
  }

  async function runNow() {
    if (!token || !selected) return;
    setBusy(true);
    setError(null);
    if (!runKey.current) runKey.current = crypto.randomUUID();
    try {
      const run = await workflowsApi.run(
        token,
        selected.id,
        triggerInput,
        runKey.current
      );
      runKey.current = null;
      setRuns((current) => [run, ...current.filter((r) => r.id !== run.id)]);
      setOpenRunId(run.id);
      setTriggerInput("");
      await loadWorkflows(selected.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "The run could not be started");
    } finally {
      setBusy(false);
    }
  }

  async function decide(decision: "approved" | "rejected") {
    if (!token || !selected || !openRun?.pending) return;
    setBusy(true);
    setError(null);
    try {
      const updated = await workflowsApi.approve(token, selected.id, openRun.id, {
        [openRun.pending.step_id]: decision,
      });
      setRuns((current) => current.map((r) => (r.id === updated.id ? updated : r)));
      await loadWorkflows(selected.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not record your decision");
    } finally {
      setBusy(false);
    }
  }

  async function setStatus(status: Workflow["status"]) {
    if (!token || !selected) return;
    setBusy(true);
    setError(null);
    try {
      await workflowsApi.update(token, selected.id, { status });
      await loadWorkflows(selected.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update the workflow");
    } finally {
      setBusy(false);
    }
  }

  const definition = selected?.definition as WorkflowDefinition | undefined;
  const steps = definition?.steps ?? [];
  const usesInput = useMemo(
    () => JSON.stringify(definition ?? {}).includes("{{ input }}"),
    [definition]
  );
  const waitingCount = workflows.filter(
    (w) => w.last_run?.status === "awaiting_approval"
  ).length;

  /* ---------------------------------------------------------------------- */

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center text-sm text-navy/50">
        <Loader2 className="mr-2 h-4 w-4 motion-safe:animate-spin" />
        Loading workflows…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-navy">Workflows</h1>
          <p className="mt-1 max-w-prose text-sm leading-relaxed text-navy/60">
            Automations that put the Council to work. Every one of them reads,
            deliberates and drafts on its own — and stops for you before it
            writes anything down or sends anything out.
          </p>
        </div>
        {waitingCount > 0 && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-700">
            <ShieldAlert className="h-3.5 w-3.5" />
            {waitingCount} waiting on you
          </span>
        )}
      </header>

      {error && (
        <div
          role="alert"
          className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
        >
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {workflows.length === 0 ? (
        <Card>
          <div className="p-8">
            <Eyebrow>No workflows yet</Eyebrow>
            <h2 className="mt-1.5 text-lg font-semibold text-navy">
              Start from one of these, then edit it
            </h2>
            <p className="mt-1 max-w-prose text-sm leading-relaxed text-navy/60">
              Both are real, runnable definitions. Neither will write anything
              without asking you first.
            </p>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {TEMPLATES.map((template) => (
                <button
                  key={template.name}
                  type="button"
                  disabled={busy}
                  onClick={() => createFromTemplate(template)}
                  className="rounded-lg border border-border bg-surface p-4 text-left transition hover:border-navy/30 hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy focus-visible:ring-offset-2 disabled:opacity-50"
                >
                  <span className="flex items-center gap-2 text-sm font-medium text-navy">
                    <Plus className="h-3.5 w-3.5 text-amber" />
                    {template.name}
                  </span>
                  <span className="mt-1 block text-xs leading-relaxed text-navy/60">
                    {template.description}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </Card>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[320px_minmax(0,1fr)]">
          {/* List ------------------------------------------------------- */}
          <div className="space-y-2">
            {workflows.map((workflow) => {
              const active = workflow.id === selectedId;
              return (
                <button
                  key={workflow.id}
                  type="button"
                  onClick={() => setSelectedId(workflow.id)}
                  aria-current={active ? "true" : undefined}
                  className={`w-full rounded-xl border p-4 text-left transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy focus-visible:ring-offset-2 ${
                    active
                      ? "border-navy/30 bg-surface-elevated shadow-soft"
                      : "border-border bg-surface-elevated/60 hover:bg-surface-elevated"
                  }`}
                >
                  <span className="flex items-start justify-between gap-2">
                    <span className="text-sm font-medium leading-snug text-navy">
                      {workflow.name}
                    </span>
                    <span className="shrink-0 rounded-full bg-surface-muted px-2 py-0.5 text-[11px] font-medium text-navy/60">
                      {workflow.status}
                    </span>
                  </span>
                  <span className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-navy/50">
                    <span>{workflow.summary.step_count} steps</span>
                    <span aria-hidden>·</span>
                    <span>
                      {workflow.summary.approval_steps.length} approval
                      {workflow.summary.approval_steps.length === 1 ? " gate" : " gates"}
                    </span>
                    {workflow.last_run && (
                      <>
                        <span aria-hidden>·</span>
                        <span
                          className={
                            workflow.last_run.status === "awaiting_approval"
                              ? "font-medium text-amber-700"
                              : ""
                          }
                        >
                          {RUN_STATUS_LABELS[workflow.last_run.status]}
                        </span>
                      </>
                    )}
                  </span>
                </button>
              );
            })}

            <div className="pt-1">
              {TEMPLATES.map((template) => (
                <button
                  key={template.name}
                  type="button"
                  disabled={busy}
                  onClick={() => createFromTemplate(template)}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-navy/60 transition hover:bg-surface-muted hover:text-navy focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy disabled:opacity-50"
                >
                  <Plus className="h-3.5 w-3.5 text-amber" />
                  {template.name}
                </button>
              ))}
            </div>
          </div>

          {/* Detail ----------------------------------------------------- */}
          {selected && (
            <div className="space-y-4">
              <Card>
                <div className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h2 className="text-lg font-semibold tracking-tight text-navy">
                        {selected.name}
                      </h2>
                      {selected.description && (
                        <p className="mt-1 max-w-prose text-sm leading-relaxed text-navy/60">
                          {selected.description}
                        </p>
                      )}
                    </div>
                    <div className="flex shrink-0 gap-2">
                      {selected.status === "active" ? (
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={busy}
                          onClick={() => setStatus("paused")}
                        >
                          Pause
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={busy || !selected.summary.valid}
                          onClick={() => setStatus("active")}
                        >
                          Activate
                        </Button>
                      )}
                    </div>
                  </div>

                  {!selected.summary.valid && (
                    <p className="mt-3 flex items-start gap-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">
                      <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0" />
                      {selected.summary.error}
                    </p>
                  )}

                  {selected.summary.awaiting_dispatcher && (
                    <p className="mt-3 flex items-start gap-2 rounded-lg bg-surface-muted px-3 py-2 text-xs text-navy/60">
                      <Clock className="mt-px h-3.5 w-3.5 shrink-0" />
                      This workflow has an {selected.summary.trigger_type} trigger.
                      Nothing dispatches those yet — start it yourself below, and
                      it will fire on its own once the event bus ships.
                    </p>
                  )}

                  {selected.next_run_at && selected.status === "active" && (
                    <p className="mt-3 flex items-start gap-2 rounded-lg bg-surface-muted px-3 py-2 text-xs text-navy/60">
                      <Clock className="mt-px h-3.5 w-3.5 shrink-0" />
                      Next scheduled run{" "}
                      {new Date(selected.next_run_at).toLocaleString(undefined, {
                        weekday: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                      . Times are UTC — a scheduled workflow does not shift with
                      daylight saving.
                    </p>
                  )}

                  <ul className="mt-4 border-t border-border/60">
                    {steps.map((step, index) => (
                      <StepRow
                        key={step.id}
                        step={step}
                        isLast={index === steps.length - 1}
                        gated={selected.summary.approval_steps.includes(step.id)}
                        label={stepLabels.get(step.type) ?? step.type}
                        result={openRun?.steps.find((r) => r.step_id === step.id)}
                      />
                    ))}
                  </ul>

                  <div className="mt-4 flex flex-wrap items-end gap-3 border-t border-border/60 pt-4">
                    {usesInput && (
                      <label className="min-w-[240px] flex-1">
                        <span className="text-[11px] font-semibold uppercase tracking-wide text-navy/40">
                          What is this run about?
                        </span>
                        <input
                          value={triggerInput}
                          onChange={(event) => setTriggerInput(event.target.value)}
                          placeholder="e.g. competitor moved to usage-based pricing in the EU"
                          className="mt-1 w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-navy placeholder:text-navy/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy"
                        />
                      </label>
                    )}
                    <Button
                      size="sm"
                      disabled={busy || !selected.summary.valid}
                      onClick={runNow}
                      aria-busy={busy}
                    >
                      {busy ? (
                        <Loader2 className="h-3.5 w-3.5 motion-safe:animate-spin" />
                      ) : (
                        <Play className="h-3.5 w-3.5" />
                      )}
                      Run now
                    </Button>
                  </div>
                </div>
              </Card>

              {openRun?.status === "awaiting_approval" && (
                <ApprovalGate run={openRun} busy={busy} onDecide={decide} />
              )}

              {openRun && openRun.status !== "awaiting_approval" && (
                <Card>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 p-4 text-xs text-navy/60">
                    <RunStatusPill status={openRun.status} />
                    <span>
                      {openRun.steps.length} of {steps.length} steps
                    </span>
                    <span>{tokens(openRun.token_usage.total_tokens)} tokens</span>
                    <span>{openRun.latency_ms}ms</span>
                    {openRun.error_message && (
                      <span className="text-red-700">{openRun.error_message}</span>
                    )}
                  </div>
                </Card>
              )}

              {runs.length > 0 && (
                <Card>
                  <div className="p-5">
                    <Eyebrow>Run history</Eyebrow>
                    <p className="mt-1 text-xs text-navy/50">
                      A halted run is one you declined. It is kept, with the
                      reason — not deleted.
                    </p>
                    <ul className="mt-3 divide-y divide-border/60">
                      {runs.map((run) => (
                        <li key={run.id}>
                          <button
                            type="button"
                            onClick={() => setOpenRunId(run.id)}
                            className={`flex w-full items-center justify-between gap-3 rounded-md px-2 py-2.5 text-left transition hover:bg-surface-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy ${
                              run.id === openRunId ? "bg-surface-muted" : ""
                            }`}
                          >
                            <span className="min-w-0">
                              <span className="block truncate text-sm text-navy">
                                {run.trigger_input || `${run.trigger} run`}
                              </span>
                              <span className="text-[11px] text-navy/45">
                                {shortTime(run.started_at)} ·{" "}
                                {tokens(run.token_usage.total_tokens)} tokens
                              </span>
                            </span>
                            <RunStatusPill status={run.status} />
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                </Card>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
