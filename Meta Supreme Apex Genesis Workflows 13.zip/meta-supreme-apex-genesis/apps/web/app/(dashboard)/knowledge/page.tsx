"use client";

/**
 * Knowledge Vault — add, search, and manage the knowledge the Council draws on.
 *
 * Text and Markdown ingestion (typed or file-based) with semantic search.
 * Items marked "simulated" were embedded by the offline mock provider.
 */

import { FileText, Loader2, Plus, Search, Trash2, Upload } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  knowledgeApi,
  type KnowledgeItem,
  type KnowledgeSearchHit,
} from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

export default function KnowledgePage() {
  const { token } = useAuth();

  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<KnowledgeSearchHit[] | null>(null);
  const [searching, setSearching] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(() => {
    if (!token) return;
    knowledgeApi
      .list(token)
      .then(setItems)
      .catch((err) => setError(err.message));
  }, [token]);

  useEffect(refresh, [refresh]);

  async function handleAdd(event: FormEvent) {
    event.preventDefault();
    if (!token || !title.trim() || !content.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const item = await knowledgeApi.create(token, {
        title: title.trim(),
        content,
        source_type: "manual",
      });
      setItems((prev) => [item, ...prev]);
      setTitle("");
      setContent("");
      setShowForm(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not add knowledge");
    } finally {
      setSaving(false);
    }
  }

  async function handleFile(file: File) {
    const text = await file.text();
    setTitle(file.name.replace(/\.(txt|md|markdown)$/i, ""));
    setContent(text);
    setShowForm(true);
  }

  async function handleSearch(event: FormEvent) {
    event.preventDefault();
    if (!token || !query.trim()) return;
    setSearching(true);
    setError(null);
    try {
      setHits(await knowledgeApi.search(token, { query: query.trim(), limit: 5 }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Search failed");
    } finally {
      setSearching(false);
    }
  }

  async function handleDelete(id: string) {
    if (!token) return;
    try {
      await knowledgeApi.remove(token, id);
      setItems((prev) => prev.filter((i) => i.id !== id));
      setHits((prev) => prev?.filter((h) => h.knowledge_item_id !== id) ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not delete item");
    }
  }

  return (
    <div>
      <div className="mb-8 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-navy">
            Knowledge Vault
          </h1>
          <p className="mt-1 text-sm text-navy/60">
            Upload, organize, and retrieve knowledge with semantic precision.
            The Council cites these sources in its responses.
          </p>
        </div>
        <div className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.md,.markdown"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void handleFile(file);
              e.target.value = "";
            }}
          />
          <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
            <Upload className="h-4 w-4" /> Upload file
          </Button>
          <Button onClick={() => setShowForm((v) => !v)}>
            <Plus className="h-4 w-4" /> Add knowledge
          </Button>
        </div>
      </div>

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700">
          {error}
        </div>
      )}

      {showForm && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-base">New knowledge item</CardTitle>
            <CardDescription>
              Content is chunked, embedded, and indexed for retrieval on save.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdd} className="space-y-4">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Title"
                required
                className="w-full rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20"
              />
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Paste or type the knowledge content…"
                required
                rows={8}
                className="w-full rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20"
              />
              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setShowForm(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Indexing…
                    </>
                  ) : (
                    "Save & index"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Items</CardTitle>
              <CardDescription>
                {items.length === 0
                  ? "Nothing indexed yet"
                  : `${items.length} item${items.length === 1 ? "" : "s"} indexed`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {items.length === 0 ? (
                <div className="rounded-lg border border-dashed border-border bg-surface-muted/50 p-12 text-center">
                  <p className="text-sm font-medium text-navy">No knowledge yet</p>
                  <p className="mt-1 text-sm text-navy/50">
                    Add text or upload .txt / .md files to enable semantic
                    retrieval for the AI Council.
                  </p>
                </div>
              ) : (
                <ul className="space-y-2">
                  {items.map((item) => (
                    <li
                      key={item.id}
                      className="flex items-center justify-between gap-3 rounded-lg border border-border/70 bg-surface-elevated px-3.5 py-3"
                    >
                      <div className="flex min-w-0 items-center gap-3">
                        <FileText className="h-4 w-4 shrink-0 text-amber" />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-navy">
                            {item.title}
                          </p>
                          <p className="text-xs text-navy/50">
                            {item.chunk_count} chunk
                            {item.chunk_count === 1 ? "" : "s"} ·{" "}
                            {item.source_type}
                            {item.metadata?.simulated_embeddings === true &&
                              " · simulated embeddings"}
                          </p>
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-2">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                            item.status === "ready"
                              ? "bg-amber-50 text-amber-700"
                              : item.status === "failed"
                                ? "bg-red-50 text-red-700"
                                : "bg-surface-muted text-navy/60"
                          }`}
                        >
                          {item.status}
                        </span>
                        <button
                          type="button"
                          onClick={() => void handleDelete(item.id)}
                          className="rounded-md p-1.5 text-navy/40 transition hover:bg-red-50 hover:text-red-600"
                          aria-label={`Delete ${item.title}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Semantic search</CardTitle>
              <CardDescription>
                Find the passages the Council would retrieve.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <form onSubmit={handleSearch} className="flex gap-2">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search your knowledge…"
                  className="flex-1 rounded-lg border border-border bg-surface-elevated px-3 py-2 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none"
                />
                <Button type="submit" size="sm" disabled={searching || !query.trim()}>
                  {searching ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Search className="h-4 w-4" />
                  )}
                </Button>
              </form>

              {hits !== null &&
                (hits.length === 0 ? (
                  <p className="text-sm text-navy/50">No matches found.</p>
                ) : (
                  <ul className="space-y-2">
                    {hits.map((hit) => (
                      <li
                        key={`${hit.knowledge_item_id}-${hit.chunk_index}`}
                        className="rounded-lg bg-surface-muted p-3"
                      >
                        <p className="text-xs font-semibold text-navy">
                          {hit.title}
                          <span className="ml-1.5 font-normal text-navy/40">
                            distance {hit.distance.toFixed(3)}
                          </span>
                        </p>
                        <p className="mt-1 line-clamp-4 text-xs leading-relaxed text-navy/70">
                          {hit.content}
                        </p>
                      </li>
                    ))}
                  </ul>
                ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
