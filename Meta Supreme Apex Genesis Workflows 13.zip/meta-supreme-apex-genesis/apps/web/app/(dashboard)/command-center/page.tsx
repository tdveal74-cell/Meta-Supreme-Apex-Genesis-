"use client";

/**
 * Command Center — live Council conversations.
 *
 * Sends real requests through the Executive Controller and renders the
 * synthesized response transparently: which agents were consulted, each
 * agent's individual contribution, points of tension, confidence, and
 * whether the output came from a real provider or the offline mock.
 */

import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  Loader2,
  Plus,
  Scale,
  Send,
  Users,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ApiError,
  conversationsApi,
  decisionsApi,
  intelligenceApi,
  type Contribution,
  type Conversation,
  type CouncilEvent,
  type CouncilResponse,
  type IntelligenceStatus,
  type Message,
} from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

type LiveAgentState = "deliberating" | "done" | "failed";

const COUNCIL = [
  "Oracle",
  "Analyst",
  "Strategist",
  "Architect",
  "Engineer",
  "Guardian",
  "Creator",
  "Librarian",
  "Skeptic",
] as const;

/* ------------------------------------------------------------------------ */
/* Small presentational helpers                                              */
/* ------------------------------------------------------------------------ */

function ConfidenceBar({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-surface-muted">
        <div
          className="h-full rounded-full bg-amber"
          style={{ width: `${Math.round(value * 100)}%` }}
        />
      </div>
      <span className="text-xs tabular-nums text-navy/50">
        {Math.round(value * 100)}%
      </span>
    </div>
  );
}

function MetaChip({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-surface-muted px-2 py-0.5 text-[11px] font-medium text-navy/60">
      {children}
    </span>
  );
}

function ContributionValue({ value }: { value: unknown }) {
  if (Array.isArray(value)) {
    return (
      <ul className="mt-1 space-y-1">
        {value.map((item, i) => (
          <li key={i} className="flex gap-2 text-sm text-navy/80">
            <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-amber" />
            <span>{typeof item === "string" ? item : JSON.stringify(item)}</span>
          </li>
        ))}
      </ul>
    );
  }
  if (typeof value === "object" && value !== null) {
    return (
      <pre className="mt-1 overflow-x-auto rounded-md bg-surface-muted p-2 text-xs text-navy/70">
        {JSON.stringify(value, null, 2)}
      </pre>
    );
  }
  return <p className="mt-1 text-sm text-navy/80">{String(value)}</p>;
}

function ContributionCard({ contribution }: { contribution: Contribution }) {
  const [open, setOpen] = useState(false);
  const failed = contribution.status === "failed";

  return (
    <div className="rounded-lg border border-border/70 bg-surface-elevated">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left"
      >
        <div className="flex items-center gap-2">
          <span
            className={`h-2 w-2 rounded-full ${failed ? "bg-red-500" : "bg-amber"}`}
          />
          <span className="text-sm font-medium text-navy">
            {contribution.agent_name}
          </span>
          {failed ? (
            <span className="text-xs text-red-600">failed</span>
          ) : (
            <ConfidenceBar value={contribution.confidence} />
          )}
        </div>
        <ChevronDown
          className={`h-4 w-4 text-navy/40 transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && (
        <div className="border-t border-border/60 px-3 py-2.5">
          {failed ? (
            <p className="text-sm text-red-700">{contribution.error}</p>
          ) : (
            <div className="space-y-2.5">
              {Object.entries(contribution.content ?? {})
                .filter(([key]) => key !== "confidence")
                .map(([key, value]) => (
                  <div key={key}>
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-navy/40">
                      {key.replaceAll("_", " ")}
                    </p>
                    <ContributionValue value={value} />
                  </div>
                ))}
              <p className="text-[11px] text-navy/40">
                {contribution.latency_ms} ms ·{" "}
                {contribution.input_tokens + contribution.output_tokens} tokens
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function AssistantMessage({
  message,
  contributions,
}: {
  message: Message;
  contributions?: Contribution[];
}) {
  const { token } = useAuth();
  const meta = message.metadata ?? {};
  const [showCouncil, setShowCouncil] = useState(false);
  const [tracked, setTracked] = useState(false);
  const [tracking, setTracking] = useState(false);

  async function trackAsDecision() {
    if (!token || tracked || tracking) return;
    setTracking(true);
    try {
      await decisionsApi.fromMessage(token, message.id);
      setTracked(true);
    } finally {
      setTracking(false);
    }
  }

  return (
    <div className="max-w-[92%] space-y-3">
      <div className="rounded-xl rounded-tl-sm border border-border/70 bg-surface-elevated p-4 shadow-soft">
        <p className="whitespace-pre-wrap text-sm leading-relaxed text-navy/90">
          {message.content}
        </p>

        {(meta.recommended_actions?.length ?? 0) > 0 && (
          <div className="mt-3 border-t border-border/60 pt-3">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-navy/40">
              Recommended actions
            </p>
            <ul className="mt-1.5 space-y-1">
              {meta.recommended_actions!.map((action, i) => (
                <li key={i} className="flex gap-2 text-sm text-navy/80">
                  <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-amber" />
                  <span>{action}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {(meta.points_of_tension?.length ?? 0) > 0 && (
          <div className="mt-3 rounded-lg bg-amber-50 p-3">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-amber-700">
              <AlertTriangle className="h-3 w-3" /> Points of tension
            </p>
            <ul className="mt-1.5 space-y-1">
              {meta.points_of_tension!.map((point, i) => (
                <li key={i} className="text-sm text-navy/80">
                  {point}
                </li>
              ))}
            </ul>
          </div>
        )}

        {(meta.knowledge_sources?.length ?? 0) > 0 && (
          <div className="mt-3 border-t border-border/60 pt-3">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-navy/40">
              <BookOpen className="h-3 w-3" /> Sources from your Knowledge Vault
            </p>
            <ul className="mt-1.5 space-y-0.5">
              {meta.knowledge_sources!.map((source, i) => (
                <li key={i} className="text-xs text-navy/70">
                  {source.title}
                  <span className="text-navy/40">
                    {" "}
                    · chunk {source.chunk_index + 1} · distance{" "}
                    {source.distance.toFixed(3)}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-1.5 border-t border-border/60 pt-3">
          {meta.intent && <MetaChip>intent: {meta.intent}</MetaChip>}
          {typeof meta.confidence === "number" && (
            <MetaChip>confidence {Math.round(meta.confidence * 100)}%</MetaChip>
          )}
          {meta.provider && (
            <MetaChip>
              {meta.provider === "mock" ? "simulated" : meta.provider}
            </MetaChip>
          )}
          {meta.synthesis_mode === "fallback" && (
            <MetaChip>fallback synthesis</MetaChip>
          )}
          {typeof meta.deliberation_rounds === "number" &&
            meta.deliberation_rounds > 1 && (
              <MetaChip>{meta.deliberation_rounds} deliberation rounds</MetaChip>
            )}
          {typeof meta.memories_recalled === "number" &&
            meta.memories_recalled > 0 && (
              <MetaChip>
                {meta.memories_recalled} memor
                {meta.memories_recalled === 1 ? "y" : "ies"} recalled
              </MetaChip>
            )}
          {typeof meta.total_latency_ms === "number" && (
            <MetaChip>{(meta.total_latency_ms / 1000).toFixed(1)}s</MetaChip>
          )}
          <span className="flex-1" />
          <button
            type="button"
            onClick={() => void trackAsDecision()}
            disabled={tracking || tracked}
            className={`flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-medium transition ${
              tracked
                ? "bg-amber-50 text-amber-700"
                : "bg-surface-muted text-navy/60 hover:bg-amber-50 hover:text-amber-700"
            }`}
          >
            {tracked ? (
              <>
                <CheckCircle2 className="h-3 w-3" /> Tracked in Decisions
              </>
            ) : (
              <>
                <Scale className="h-3 w-3" />
                {tracking ? "Tracking…" : "Track as decision"}
              </>
            )}
          </button>
        </div>
      </div>

      {(meta.agents_consulted?.length ?? 0) > 0 && (
        <div>
          <button
            type="button"
            onClick={() => setShowCouncil((v) => !v)}
            className="flex items-center gap-1.5 text-xs font-medium text-navy/50 transition hover:text-navy"
          >
            <Users className="h-3.5 w-3.5" />
            Council: {meta.agents_consulted!.join(", ")}
            {contributions && contributions.length > 0 && (
              <ChevronDown
                className={`h-3.5 w-3.5 transition-transform ${showCouncil ? "rotate-180" : ""}`}
              />
            )}
          </button>
          {showCouncil && contributions && contributions.length > 0 && (
            <div className="mt-2 space-y-2">
              {contributions.map((c) => (
                <ContributionCard key={c.agent_slug} contribution={c} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------------ */
/* Page                                                                      */
/* ------------------------------------------------------------------------ */

export default function CommandCenterPage() {
  const { token } = useAuth();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [contributionsByMessage, setContributionsByMessage] = useState<
    Record<string, Contribution[]>
  >({});
  const [status, setStatus] = useState<IntelligenceStatus | null>(null);

  const [input, setInput] = useState("");
  const [fullCouncil, setFullCouncil] = useState(false);
  const [deliberate, setDeliberate] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastConsulted, setLastConsulted] = useState<string[]>([]);
  const [liveStatus, setLiveStatus] = useState<Record<string, LiveAgentState>>({});
  const [liveRound, setLiveRound] = useState(1);
  const [liveStage, setLiveStage] = useState<string | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);

  /* -- data loading ------------------------------------------------------ */

  useEffect(() => {
    if (!token) return;
    conversationsApi
      .list(token)
      .then((list) => {
        setConversations(list);
        if (list.length > 0) setActiveId((current) => current ?? list[0].id);
      })
      .catch((err) => setError(err.message));
    intelligenceApi
      .status(token)
      .then(setStatus)
      .catch(() => setStatus(null));
  }, [token]);

  useEffect(() => {
    if (!token || !activeId) {
      setMessages([]);
      return;
    }
    conversationsApi
      .get(token, activeId)
      .then((detail) => {
        setMessages(detail.messages);
        const lastAssistant = [...detail.messages]
          .reverse()
          .find((m) => m.role === "assistant");
        setLastConsulted(lastAssistant?.metadata?.agents_consulted ?? []);
      })
      .catch((err) => setError(err.message));
  }, [token, activeId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [messages, sending]);

  /* -- actions ----------------------------------------------------------- */

  const startConversation = useCallback(async () => {
    if (!token) return;
    try {
      const created = await conversationsApi.create(token, {});
      setConversations((prev) => [created, ...prev]);
      setActiveId(created.id);
      setMessages([]);
      setLastConsulted([]);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create conversation");
    }
  }, [token]);

  async function handleSend(event: FormEvent) {
    event.preventDefault();
    if (!token || !input.trim() || sending) return;

    let conversationId = activeId;
    setError(null);
    setSending(true);
    const content = input.trim();
    setInput("");

    try {
      if (!conversationId) {
        const created = await conversationsApi.create(token, {});
        setConversations((prev) => [created, ...prev]);
        setActiveId(created.id);
        conversationId = created.id;
      }
      const targetId: string = conversationId;

      // Optimistic user message while the Council deliberates.
      const pendingId = `pending-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: pendingId,
          conversation_id: targetId,
          role: "user",
          content,
          metadata: {},
          token_count: null,
          created_at: new Date().toISOString(),
        },
      ]);

      // Live streaming with graceful fallback to the plain endpoint.
      const handleEvent = (event: CouncilEvent) => {
        if (event.type === "agents_selected") {
          setLiveStatus(
            Object.fromEntries(event.agents.map((slug) => [slug, "deliberating"]))
          );
          setLiveStage(event.rounds > 1 ? "Round 1 of 2" : null);
        } else if (event.type === "agent_started") {
          setLiveRound(event.round);
          if (event.round > 1) setLiveStage(`Round ${event.round} of 2 — deliberating`);
          setLiveStatus((prev) => ({ ...prev, [event.agent]: "deliberating" }));
        } else if (event.type === "agent_completed") {
          setLiveStatus((prev) => ({
            ...prev,
            [event.agent]: event.status === "completed" ? "done" : "failed",
          }));
        } else if (event.type === "synthesis_started") {
          setLiveStage("Synthesizing the Council's response…");
        }
      };

      let result: CouncilResponse;
      try {
        result = await conversationsApi.sendMessageStream(
          token,
          targetId,
          { content, full_council: fullCouncil, deliberate },
          handleEvent
        );
      } catch (streamError) {
        // API-level errors (auth, validation, council failure) are final;
        // transport/parse failures fall back to the plain endpoint once.
        if (streamError instanceof ApiError) {
          throw streamError;
        }
        result = await conversationsApi.sendMessage(token, targetId, {
          content,
          full_council: fullCouncil,
          deliberate,
        });
      }

      setMessages((prev) => [
        ...prev.filter((m) => m.id !== pendingId),
        result.user_message,
        result.assistant_message,
      ]);
      setContributionsByMessage((prev) => ({
        ...prev,
        [result.assistant_message.id]: result.contributions,
      }));
      setLastConsulted(result.agents_consulted);
      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetId
            ? {
                ...c,
                title: c.title ?? content.slice(0, 80),
                message_count: c.message_count + 2,
              }
            : c
        )
      );
    } catch (err) {
      setMessages((prev) => prev.filter((m) => !m.id.startsWith("pending-")));
      setInput(content); // let the user retry without retyping
      setError(err instanceof Error ? err.message : "The Council request failed");
    } finally {
      setSending(false);
      setLiveStatus({});
      setLiveRound(1);
      setLiveStage(null);
    }
  }

  /* -- render ------------------------------------------------------------ */

  return (
    <div>
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-navy">
            Command Center
          </h1>
          <p className="mt-1 text-sm text-navy/60">
            Converse with the system, activate the AI Council, and receive
            synthesized intelligence.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {conversations.length > 0 && (
            <select
              value={activeId ?? ""}
              onChange={(e) => setActiveId(e.target.value || null)}
              className="h-9 max-w-[220px] rounded-lg border border-border bg-surface-elevated px-3 text-sm text-navy focus:border-amber focus:outline-none"
              aria-label="Select conversation"
            >
              {conversations.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title || "Untitled conversation"}
                </option>
              ))}
            </select>
          )}
          <Button variant="outline" size="sm" onClick={startConversation}>
            <Plus className="h-4 w-4" /> New
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main conversation area */}
        <div className="lg:col-span-2">
          <Card className="flex min-h-[560px] flex-col">
            <CardHeader className="border-b border-border/60">
              <CardTitle className="text-base">Conversation</CardTitle>
              <CardDescription>
                Every response is synthesized from specialized Council agents —
                expand any reply to see each agent&apos;s contribution.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-1 flex-col p-0">
              <div
                ref={scrollRef}
                className="flex-1 space-y-5 overflow-y-auto p-4"
                style={{ maxHeight: "56vh" }}
              >
                {messages.length === 0 && !sending && (
                  <div className="rounded-lg bg-surface-muted p-4 text-sm text-navy/70">
                    Ask a question, frame a decision, or request a plan. The
                    Executive Controller will detect your intent, consult the
                    right Council agents, and return one synthesized response —
                    with every agent&apos;s reasoning kept visible.
                  </div>
                )}

                <AnimatePresence initial={false}>
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className={
                        message.role === "user" ? "flex justify-end" : "flex"
                      }
                    >
                      {message.role === "user" ? (
                        <div className="max-w-[85%] rounded-xl rounded-tr-sm bg-navy px-4 py-3 text-sm leading-relaxed text-surface shadow-soft">
                          {message.content}
                        </div>
                      ) : (
                        <AssistantMessage
                          message={message}
                          contributions={contributionsByMessage[message.id]}
                        />
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>

                {sending && (
                  <div className="flex items-center gap-2.5 text-sm text-navy/50">
                    <Loader2 className="h-4 w-4 animate-spin text-amber" />
                    {liveStage ?? "The Council is deliberating…"}
                  </div>
                )}
              </div>

              {error && (
                <div className="mx-4 mb-2 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700">
                  {error}
                </div>
              )}

              <form
                onSubmit={handleSend}
                className="flex items-center gap-2 border-t border-border/60 p-4"
              >
                <label className="flex shrink-0 cursor-pointer items-center gap-1.5 text-xs text-navy/60">
                  <input
                    type="checkbox"
                    checked={fullCouncil}
                    onChange={(e) => setFullCouncil(e.target.checked)}
                    className="h-3.5 w-3.5 rounded border-border text-amber focus:ring-amber/30"
                  />
                  Full Council
                </label>
                <label
                  className="flex shrink-0 cursor-pointer items-center gap-1.5 text-xs text-navy/60"
                  title="Agents see each other's first-round contributions and revise before synthesis."
                >
                  <input
                    type="checkbox"
                    checked={deliberate}
                    onChange={(e) => setDeliberate(e.target.checked)}
                    className="h-3.5 w-3.5 rounded border-border text-amber focus:ring-amber/30"
                  />
                  Deliberate
                </label>
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask anything…"
                  disabled={sending}
                  className="flex-1 rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20 disabled:opacity-60"
                />
                <Button type="submit" disabled={sending || !input.trim()}>
                  <Send className="h-4 w-4" />
                  Send
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Council / status panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">AI Council</CardTitle>
              <CardDescription>
                {sending && liveRound > 1
                  ? `Live deliberation — round ${liveRound}`
                  : sending
                    ? "Live agent status"
                    : "Agent status"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {COUNCIL.map((name) => {
                const slug = name.toLowerCase();
                const live = liveStatus[slug];
                const consulted = lastConsulted.includes(slug);

                // While streaming, the live event feed drives the panel;
                // otherwise the last completed exchange does.
                const state: "active" | "done" | "failed" | "idle" = sending
                  ? live === "deliberating"
                    ? "active"
                    : live === "done"
                      ? "done"
                      : live === "failed"
                        ? "failed"
                        : "idle"
                  : consulted
                    ? "done"
                    : "idle";

                const label = sending
                  ? state === "active"
                    ? "Deliberating…"
                    : state === "done"
                      ? "Contributed"
                      : state === "failed"
                        ? "Failed"
                        : "Standby"
                  : consulted
                    ? "Consulted"
                    : "Standby";

                return (
                  <div
                    key={name}
                    className={`flex items-center justify-between rounded-md px-3 py-2 text-sm transition ${
                      state === "done" || state === "active"
                        ? "bg-amber-50"
                        : state === "failed"
                          ? "bg-red-50"
                          : "bg-surface-muted"
                    }`}
                  >
                    <span className="flex items-center gap-2 font-medium text-navy">
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${
                          state === "active"
                            ? "animate-pulse bg-amber"
                            : state === "done"
                              ? "bg-amber"
                              : state === "failed"
                                ? "bg-red-500"
                                : "bg-navy/20"
                        }`}
                      />
                      {name}
                    </span>
                    <span
                      className={`text-xs ${
                        state === "done" || state === "active"
                          ? "text-amber-700"
                          : state === "failed"
                            ? "text-red-600"
                            : "text-navy/50"
                      }`}
                    >
                      {label}
                    </span>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Intelligence</CardTitle>
              <CardDescription>Provider status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              {status ? (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-navy/60">Provider</span>
                    <span className="font-medium text-navy">{status.provider}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-navy/60">Model</span>
                    <span className="font-medium text-navy">{status.model}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-navy/60">Execution</span>
                    <span className="font-medium text-navy">
                      {status.parallel_execution ? "Parallel" : "Sequential"}
                    </span>
                  </div>
                  {status.simulated && (
                    <p className="mt-2 rounded-lg bg-amber-50 p-2.5 text-xs leading-relaxed text-amber-800">
                      Running in simulated mode — responses are deterministic
                      placeholders. Configure an AI provider key to activate
                      live intelligence.
                    </p>
                  )}
                </>
              ) : (
                <p className="text-navy/50">Status unavailable.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
