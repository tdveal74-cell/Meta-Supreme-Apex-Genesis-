import Link from "next/link";
import { ReactNode } from "react";

import { AuthGuard } from "@/components/auth-guard";
import { UserMenu } from "@/components/user-menu";

const navItems = [
  { href: "/dashboard", label: "Overview" },
  { href: "/command-center", label: "Command Center" },
  { href: "/knowledge", label: "Knowledge Vault" },
  { href: "/decisions", label: "Decisions" },
  { href: "/workflows", label: "Workflows" },
  { href: "/settings", label: "Settings" },
];

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-surface">
      {/* Top navigation */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-surface-elevated/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-6">
            <Link href="/dashboard" className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-navy">
                <span className="text-xs font-bold text-amber">MS</span>
              </div>
              <span className="hidden text-sm font-semibold tracking-tight text-navy sm:block">
                Meta Supreme
              </span>
            </Link>

            <nav className="hidden items-center gap-1 md:flex">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="rounded-md px-3 py-1.5 text-sm font-medium text-navy/70 transition hover:bg-surface-muted hover:text-navy"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden text-xs text-navy/50 sm:block">
              MVP · Intelligence OS
            </div>
            <UserMenu />
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <AuthGuard>{children}</AuthGuard>
      </main>
    </div>
  );
}
