"use client";

/**
 * Decision Center — track decisions, record the human's final call,
 * and review outcomes. The Council recommends; you decide.
 */

import { CheckCircle2, ChevronDown, Plus, Scale } from "lucide-react";
import { useCallback, useEffect, useState, type FormEvent } from "react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { decisionsApi, type Decision } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

const STATUS_STYLES: Record<string, string> = {
  open: "bg-amber-50 text-amber-700",
  decided: "bg-navy/10 text-navy",
  reviewed: "bg-surface-muted text-navy/70",
  archived: "bg-surface-muted text-navy/40",
};

function DecisionCard({
  decision,
  onUpdated,
}: {
  decision: Decision;
  onUpdated: (d: Decision) => void;
}) {
  const { token } = useAuth();
  const [open, setOpen] = useState(false);
  const [choice, setChoice] = useState(decision.chosen_option ?? "");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fromCouncil = decision.metadata?.origin === "council";

  async function recordDecision(event: FormEvent) {
    event.preventDefault();
    if (!token || !choice.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const updated = await decisionsApi.update(token, decision.id, {
        chosen_option: choice.trim(),
        outcome_notes: notes.trim() || undefined,
      });
      onUpdated(updated);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not record decision");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-start justify-between gap-3 p-5 text-left"
      >
        <div className="min-w-0">
          <p className="text-sm font-medium leading-snug text-navy">
            {decision.question}
          </p>
          <p className="mt-1 text-xs text-navy/50">
            {fromCouncil ? "From Council exchange" : "Manually tracked"} ·{" "}
            {new Date(decision.created_at).toLocaleDateString()}
            {decision.chosen_option && (
              <span className="text-navy/70">
                {" "}
                · chose: {decision.chosen_option}
              </span>
            )}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span
            className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${STATUS_STYLES[decision.status] ?? ""}`}
          >
            {decision.status}
          </span>
          <ChevronDown
            className={`h-4 w-4 text-navy/40 transition-transform ${open ? "rotate-180" : ""}`}
          />
        </div>
      </button>

      {open && (
        <CardContent className="border-t border-border/60 pt-4">
          {decision.recommendation && (
            <div className="mb-4">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-navy/40">
                Council recommendation
              </p>
              <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-navy/80">
                {decision.recommendation}
              </p>
            </div>
          )}

          {decision.options.length > 0 && (
            <div className="mb-4">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-navy/40">
                Options considered
              </p>
              <ul className="mt-1.5 space-y-1">
                {decision.options.map((option, i) => (
                  <li key={i} className="flex gap-2 text-sm text-navy/80">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-amber" />
                    {option}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {decision.status === "open" ? (
            <form onSubmit={recordDecision} className="rounded-lg bg-surface-muted p-4">
              <p className="flex items-center gap-1.5 text-xs font-semibold text-navy">
                <Scale className="h-3.5 w-3.5 text-amber" />
                Your decision — the final call is yours, not the Council&apos;s.
              </p>
              <input
                type="text"
                value={choice}
                onChange={(e) => setChoice(e.target.value)}
                placeholder="What did you decide?"
                required
                className="mt-2 w-full rounded-lg border border-border bg-surface-elevated px-3 py-2 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none"
              />
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Notes (optional)"
                rows={2}
                className="mt-2 w-full rounded-lg border border-border bg-surface-elevated px-3 py-2 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none"
              />
              {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
              <div className="mt-2 flex justify-end">
                <Button type="submit" size="sm" disabled={saving || !choice.trim()}>
                  <CheckCircle2 className="h-4 w-4" /> Record decision
                </Button>
              </div>
            </form>
          ) : (
            <div className="rounded-lg bg-surface-muted p-4 text-sm">
              <p className="text-navy">
                <span className="font-medium">Decided:</span>{" "}
                {decision.chosen_option}
              </p>
              {decision.outcome && (
                <p className="mt-1 text-navy/70">
                  <span className="font-medium">Outcome:</span> {decision.outcome}
                </p>
              )}
              {decision.outcome_notes && (
                <p className="mt-1 text-navy/60">{decision.outcome_notes}</p>
              )}
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
}

export default function DecisionsPage() {
  const { token } = useAuth();
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [question, setQuestion] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(() => {
    if (!token) return;
    decisionsApi
      .list(token)
      .then(setDecisions)
      .catch((err) => setError(err.message));
  }, [token]);

  useEffect(refresh, [refresh]);

  async function handleCreate(event: FormEvent) {
    event.preventDefault();
    if (!token || !question.trim()) return;
    setSaving(true);
    try {
      const created = await decisionsApi.create(token, {
        question: question.trim(),
      });
      setDecisions((prev) => [created, ...prev]);
      setQuestion("");
      setShowForm(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create decision");
    } finally {
      setSaving(false);
    }
  }

  function handleUpdated(updated: Decision) {
    setDecisions((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
  }

  const openCount = decisions.filter((d) => d.status === "open").length;

  return (
    <div>
      <div className="mb-8 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-navy">
            Decisions
          </h1>
          <p className="mt-1 text-sm text-navy/60">
            Track what was asked, what the Council recommended, and what you
            decided. {openCount > 0 && `${openCount} awaiting your call.`}
          </p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)}>
          <Plus className="h-4 w-4" /> Track decision
        </Button>
      </div>

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700">
          {error}
        </div>
      )}

      {showForm && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-base">New decision</CardTitle>
            <CardDescription>
              You can also track decisions directly from a Command Center
              exchange.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreate} className="flex gap-2">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="What needs to be decided?"
                required
                className="flex-1 rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20"
              />
              <Button type="submit" disabled={saving || !question.trim()}>
                Create
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {decisions.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-sm font-medium text-navy">No decisions tracked yet</p>
            <p className="mt-1 text-sm text-navy/50">
              Ask the Council something in the Command Center, then choose
              &ldquo;Track as decision&rdquo; on its response — or create one
              manually.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {decisions.map((decision) => (
            <DecisionCard
              key={decision.id}
              decision={decision}
              onUpdated={handleUpdated}
            />
          ))}
        </div>
      )}
    </div>
  );
}
