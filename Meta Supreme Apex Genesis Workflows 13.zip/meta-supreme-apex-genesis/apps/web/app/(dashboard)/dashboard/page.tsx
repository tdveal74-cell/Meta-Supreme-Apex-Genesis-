import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function DashboardPage() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold tracking-tight text-navy">
          Overview
        </h1>
        <p className="mt-1 text-sm text-navy/60">
          Your intelligence operating system at a glance.
        </p>
      </div>

      {/* Metrics */}
      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Active Projects", value: "—" },
          { label: "Knowledge Items", value: "—" },
          { label: "Council Runs", value: "—" },
          { label: "Decisions Tracked", value: "—" },
        ].map((metric) => (
          <Card key={metric.label}>
            <CardContent className="p-5">
              <p className="text-sm font-medium text-navy/60">{metric.label}</p>
              <p className="mt-1 text-2xl font-semibold text-navy">
                {metric.value}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick actions */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Command Center</CardTitle>
            <CardDescription>
              Start a conversation, activate the AI Council, and receive
              synthesized intelligence.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/command-center">Open Command Center</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Knowledge Vault</CardTitle>
            <CardDescription>
              Upload documents, organize knowledge, and enable semantic
              retrieval for every decision.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild>
              <Link href="/knowledge">Open Knowledge Vault</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent activity placeholder */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>
            Activity will appear here once you begin using the system.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-navy/50">
            No activity yet. Create a project or open the Command Center to get started.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
