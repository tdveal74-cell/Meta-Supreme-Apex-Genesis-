"use client";

/**
 * Settings — profile summary and Memory management.
 *
 * Memory is transparent by default: everything the system remembers is
 * listed here, editable in place, and permanently deletable.
 */

import { Brain, Pencil, Plus, Trash2, X } from "lucide-react";
import { useCallback, useEffect, useState, type FormEvent } from "react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { memoryApi, type Memory } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

function MemoryRow({
  memory,
  onChanged,
  onDeleted,
}: {
  memory: Memory;
  onChanged: (m: Memory) => void;
  onDeleted: (id: string) => void;
}) {
  const { token } = useAuth();
  const [editing, setEditing] = useState(false);
  const [content, setContent] = useState(memory.content);
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!token || !content.trim()) return;
    setSaving(true);
    try {
      onChanged(await memoryApi.update(token, memory.id, { content: content.trim() }));
      setEditing(false);
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive() {
    if (!token) return;
    onChanged(
      await memoryApi.update(token, memory.id, { is_active: !memory.is_active })
    );
  }

  async function remove() {
    if (!token) return;
    await memoryApi.remove(token, memory.id);
    onDeleted(memory.id);
  }

  return (
    <li
      className={`rounded-lg border border-border/70 bg-surface-elevated p-3.5 ${
        memory.is_active ? "" : "opacity-60"
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          {editing ? (
            <div className="flex gap-2">
              <input
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="flex-1 rounded-lg border border-border bg-surface px-3 py-1.5 text-sm text-navy focus:border-amber focus:outline-none"
              />
              <Button size="sm" onClick={() => void save()} disabled={saving}>
                Save
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <p className="text-sm leading-relaxed text-navy/85">{memory.content}</p>
          )}
          <p className="mt-1.5 text-[11px] text-navy/45">
            {memory.memory_type} · importance {memory.importance}/10 ·{" "}
            {memory.metadata?.origin === "user" ? "added by you" : "from a Council exchange"} ·{" "}
            {new Date(memory.created_at).toLocaleDateString()}
            {!memory.is_active && " · paused"}
          </p>
        </div>
        {!editing && (
          <div className="flex shrink-0 items-center gap-1">
            <button
              type="button"
              onClick={() => setEditing(true)}
              className="rounded-md p-1.5 text-navy/40 transition hover:bg-surface-muted hover:text-navy"
              aria-label="Edit memory"
            >
              <Pencil className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => void toggleActive()}
              className="rounded-md px-2 py-1 text-[11px] font-medium text-navy/50 transition hover:bg-surface-muted hover:text-navy"
            >
              {memory.is_active ? "Pause" : "Resume"}
            </button>
            <button
              type="button"
              onClick={() => void remove()}
              className="rounded-md p-1.5 text-navy/40 transition hover:bg-red-50 hover:text-red-600"
              aria-label="Delete memory"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>
    </li>
  );
}

export default function SettingsPage() {
  const { user, token } = useAuth();
  const [memories, setMemories] = useState<Memory[]>([]);
  const [newMemory, setNewMemory] = useState("");
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(() => {
    if (!token) return;
    memoryApi
      .list(token)
      .then(setMemories)
      .catch((err) => setError(err.message));
  }, [token]);

  useEffect(refresh, [refresh]);

  async function handleAdd(event: FormEvent) {
    event.preventDefault();
    if (!token || !newMemory.trim()) return;
    setAdding(true);
    try {
      const created = await memoryApi.create(token, {
        content: newMemory.trim(),
        memory_type: "preference",
        importance: 7,
      });
      setMemories((prev) => [created, ...prev]);
      setNewMemory("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not add memory");
    } finally {
      setAdding(false);
    }
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold tracking-tight text-navy">
          Settings
        </h1>
        <p className="mt-1 text-sm text-navy/60">
          Account, memory, and system configuration.
        </p>
      </div>

      <div className="grid max-w-3xl gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Profile</CardTitle>
            <CardDescription>Your account information.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-navy">
                Full name
              </label>
              <input
                type="text"
                disabled
                value={user?.full_name ?? ""}
                placeholder="Your name"
                className="w-full rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy disabled:opacity-70"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-navy">
                Email
              </label>
              <input
                type="email"
                disabled
                value={user?.email ?? ""}
                className="w-full rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy disabled:opacity-70"
              />
            </div>
            <p className="text-xs text-navy/50">
              Profile editing arrives with the account-management work in a
              later phase.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-4 w-4 text-amber" /> Memory
            </CardTitle>
            <CardDescription>
              Everything the system remembers about you. Transparent by
              default — edit, pause, or permanently delete anything here.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleAdd} className="flex gap-2">
              <input
                type="text"
                value={newMemory}
                onChange={(e) => setNewMemory(e.target.value)}
                placeholder="Teach the system something (e.g. “I prefer concise answers”)"
                className="flex-1 rounded-lg border border-border bg-surface-elevated px-3.5 py-2.5 text-sm text-navy placeholder:text-navy/40 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/20"
              />
              <Button type="submit" disabled={adding || !newMemory.trim()}>
                <Plus className="h-4 w-4" /> Add
              </Button>
            </form>

            {error && (
              <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
                {error}
              </p>
            )}

            {memories.length === 0 ? (
              <p className="rounded-lg bg-surface-muted p-4 text-sm text-navy/60">
                Nothing remembered yet. Memories are created from Council
                exchanges and from anything you add here — and they influence
                future responses.
              </p>
            ) : (
              <ul className="space-y-2">
                {memories.map((memory) => (
                  <MemoryRow
                    key={memory.id}
                    memory={memory}
                    onChanged={(m) =>
                      setMemories((prev) =>
                        prev.map((x) => (x.id === m.id ? m : x))
                      )
                    }
                    onDeleted={(id) =>
                      setMemories((prev) => prev.filter((x) => x.id !== id))
                    }
                  />
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Plan</CardTitle>
            <CardDescription>Current plan: Free</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-navy/60">
              Billing, usage limits, and plan upgrades arrive with the SaaS
              layer (Phase 6).
            </p>
            <Button disabled>Upgrade</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
