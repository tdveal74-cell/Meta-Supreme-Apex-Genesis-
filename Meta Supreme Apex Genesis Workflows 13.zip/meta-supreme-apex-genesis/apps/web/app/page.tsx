import Link from "next/link";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="border-b border-border/60 bg-surface-elevated/80 backdrop-blur-sm">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy">
              <span className="text-sm font-bold text-amber">MS</span>
            </div>
            <span className="text-lg font-semibold tracking-tight text-navy">
              Meta Supreme
            </span>
          </div>
          <nav className="flex items-center gap-4">
            <Link
              href="/login"
              className="text-sm font-medium text-navy/70 transition hover:text-navy"
            >
              Sign in
            </Link>
            <Link
              href="/login"
              className="rounded-lg bg-navy px-4 py-2 text-sm font-medium text-surface transition hover:bg-navy-800"
            >
              Get started
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <main className="mx-auto max-w-6xl px-6 py-24">
        <div className="mx-auto max-w-3xl text-center">
          <p className="mb-4 text-sm font-medium uppercase tracking-widest text-amber">
            Intelligence Operating System
          </p>
          <h1 className="text-balance text-4xl font-semibold tracking-tight text-navy sm:text-5xl md:text-6xl">
            Think clearly.
            <br />
            Decide better.
            <br />
            Execute with leverage.
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-navy/70">
            Multi-agent reasoning, knowledge management, long-term memory, and
            decision intelligence — designed to amplify human judgment, not
            replace it.
          </p>
          <div className="mt-10 flex items-center justify-center gap-4">
            <Link
              href="/login"
              className="rounded-lg bg-navy px-6 py-3 text-sm font-medium text-surface shadow-soft transition hover:bg-navy-800"
            >
              Enter Command Center
            </Link>
            <Link
              href="#vision"
              className="rounded-lg border border-border bg-surface-elevated px-6 py-3 text-sm font-medium text-navy transition hover:bg-surface-muted"
            >
              Learn more
            </Link>
          </div>
        </div>

        {/* Vision section */}
        <section id="vision" className="mt-32 grid gap-8 md:grid-cols-3">
          {[
            {
              title: "AI Council",
              description:
                "Nine specialized agents collaborate — Oracle, Analyst, Strategist, Architect, Engineer, Guardian, Creator, Librarian, and Skeptic.",
            },
            {
              title: "Knowledge + Memory",
              description:
                "Upload documents, retrieve with semantic precision, and maintain transparent long-term memory that improves over time.",
            },
            {
              title: "Decision Intelligence",
              description:
                "Structure questions, explore options, surface tradeoffs, and track outcomes so future decisions get smarter.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-xl border border-border bg-surface-elevated p-6 shadow-soft"
            >
              <h3 className="text-lg font-semibold text-navy">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-navy/70">
                {item.description}
              </p>
            </div>
          ))}
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/60 py-8">
        <div className="mx-auto max-w-6xl px-6 text-center text-sm text-navy/50">
          Meta Supreme Apex Genesis · Intelligence Operating System
        </div>
      </footer>
    </div>
  );
}
