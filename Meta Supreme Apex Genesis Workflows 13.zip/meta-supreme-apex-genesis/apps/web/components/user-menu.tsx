"use client";

/**
 * Header user chip: initial, name, and sign-out.
 */

import { useRouter } from "next/navigation";

import { useAuth } from "@/lib/auth-context";

export function UserMenu() {
  const { user, logout } = useAuth();
  const router = useRouter();

  const initial =
    user?.full_name?.trim()?.[0]?.toUpperCase() ||
    user?.email?.[0]?.toUpperCase() ||
    "U";

  return (
    <div className="flex items-center gap-3">
      <div className="hidden text-right sm:block">
        <p className="text-xs font-medium leading-tight text-navy">
          {user?.full_name || user?.email || ""}
        </p>
        <button
          type="button"
          onClick={() => {
            logout();
            router.replace("/login");
          }}
          className="text-xs text-navy/50 transition hover:text-amber-600"
        >
          Sign out
        </button>
      </div>
      <div
        className="flex h-8 w-8 items-center justify-center rounded-full bg-navy text-xs font-medium text-amber"
        aria-hidden
      >
        {initial}
      </div>
    </div>
  );
}
