"use client";

/**
 * Route guard for authenticated areas. Redirects to /login when no valid
 * session exists; shows a calm placeholder while the session restores.
 */

import { useRouter } from "next/navigation";
import { useEffect, type ReactNode } from "react";

import { useAuth } from "@/lib/auth-context";

export function AuthGuard({ children }: { children: ReactNode }) {
  const { token, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !token) {
      router.replace("/login");
    }
  }, [loading, token, router]);

  if (loading || !token) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="flex items-center gap-3 text-sm text-navy/50">
          <span className="h-2 w-2 animate-pulse rounded-full bg-amber" />
          Verifying session…
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
