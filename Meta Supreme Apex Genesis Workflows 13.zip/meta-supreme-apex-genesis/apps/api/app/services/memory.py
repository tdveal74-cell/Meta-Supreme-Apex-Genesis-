"""
Application-layer memory service.

Non-negotiables (from the platform blueprint):
- Transparent: every memory is visible to its owner via the API/UI.
- Editable: content, importance, and active state can be changed.
- Deletable: hard delete, no soft-hiding.

Phase 5 slice: after each successful Council run the controller's memory
*candidates* are persisted as real memories; at request time the most
relevant recent memories are recalled into the Council's context. Recall
is lexical (keyword overlap × importance × recency) — embedding-based
memory recall is a later refinement, and pretending otherwise would
violate the honesty rules.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.memory import Memory
from services.intelligence import SynthesisResult

logger = logging.getLogger(__name__)

_TOKEN_RE = re.compile(r"[a-z0-9]{3,}")
_STOPWORDS = frozenset(
    "the and for with that this from should would could про what when where "
    "how why are was were been being have has had our your their about into "
    "over under between".split()
)


def _tokens(text: str) -> set:
    return {t for t in _TOKEN_RE.findall(text.lower()) if t not in _STOPWORDS}


async def persist_memory_candidates(
    db: AsyncSession,
    *,
    user_id: str,
    project_id: Optional[str],
    conversation_id: Optional[str],
    message: str,
    result: SynthesisResult,
) -> List[Memory]:
    """Persist the Council's memory candidates as user-owned memories."""
    if not settings.MEMORY_ENABLED:
        return []

    stored: List[Memory] = []
    for candidate in result.memory_updates:
        if candidate.get("type") != "interaction_summary":
            continue
        summary = (
            f"Asked: \"{message.strip()[:180]}\" — intent {result.intent.value}; "
            f"council ({', '.join(result.agents_consulted)}) responded with "
            f"confidence {result.confidence:.0%}."
        )
        memory = Memory(
            user_id=user_id,
            project_id=project_id,
            memory_type="context",
            content=summary,
            importance=_importance_from_confidence(result.confidence),
            is_active=True,
            meta={
                "origin": "council_interaction",
                "request_id": result.request_id,
                "conversation_id": conversation_id,
                "intent": result.intent.value,
                "agents_consulted": result.agents_consulted,
            },
        )
        db.add(memory)
        stored.append(memory)

    if stored:
        await db.flush()
    return stored


async def recall_memories(
    db: AsyncSession,
    *,
    user_id: str,
    message: str,
    project_id: Optional[str] = None,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Recall the most relevant active memories for a request.

    Scoring: keyword overlap with the message, weighted by importance,
    with recency as the tiebreaker. Returns dicts shaped for
    ContextPacket.retrieved_memories.
    """
    if not settings.MEMORY_ENABLED:
        return []
    limit = limit or settings.MEMORY_RECALL_LIMIT

    stmt = (
        select(Memory)
        .where(Memory.user_id == user_id, Memory.is_active.is_(True))
        .order_by(Memory.updated_at.desc())
        .limit(200)  # score over the recent working set, not the whole table
    )
    if project_id:
        stmt = stmt.where(
            (Memory.project_id == project_id) | (Memory.project_id.is_(None))
        )

    result = await db.execute(stmt)
    memories = list(result.scalars().all())
    if not memories:
        return []

    query_tokens = _tokens(message)
    scored = []
    for position, memory in enumerate(memories):
        overlap = len(query_tokens & _tokens(memory.content))
        recency_bonus = max(0.0, 1.0 - position / 200)
        score = overlap * (memory.importance / 10) + 0.1 * recency_bonus
        scored.append((score, memory))

    scored.sort(key=lambda pair: pair[0], reverse=True)
    top = [memory for score, memory in scored[:limit] if score > 0]
    return [
        {
            "memory_id": m.id,
            "type": m.memory_type,
            "content": m.content,
            "importance": m.importance,
        }
        for m in top
    ]


def _importance_from_confidence(confidence: float) -> int:
    """Map council confidence to a 1-10 importance (bounded 3-7 for auto-memories)."""
    return max(3, min(7, round(3 + confidence * 4)))
