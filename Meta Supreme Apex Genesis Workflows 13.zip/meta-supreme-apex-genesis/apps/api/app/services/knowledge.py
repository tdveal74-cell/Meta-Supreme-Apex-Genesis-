"""
Application-layer knowledge service.

Ingestion: text → knowledge_item row → chunk → embed → embeddings rows.
Retrieval: query → embedding → pgvector cosine search over the owner's
ready items → ranked chunks with source attribution.

The stack decision (PostgreSQL + pgvector) comes from ARCHITECTURE.md and
is deliberate: knowledge lives beside the rest of the tenant data under
the same ownership and transaction model.
"""

from __future__ import annotations

import hashlib
import logging
from functools import lru_cache
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.knowledge import Embedding, KnowledgeItem
from services.intelligence.providers import EmbeddingProvider, create_embedding_provider
from services.knowledge import chunk_text

logger = logging.getLogger(__name__)


@lru_cache
def get_embedding_provider() -> EmbeddingProvider:
    """Build the configured embedding provider once per process."""
    provider = create_embedding_provider(
        settings.EMBEDDING_PROVIDER,
        openai_api_key=settings.OPENAI_API_KEY,
        model=settings.EMBEDDING_MODEL,
        timeout_seconds=settings.AI_TIMEOUT_SECONDS,
        max_retries=settings.AI_MAX_RETRIES,
    )
    logger.info(
        "embedding provider initialized: %s (model=%s)",
        provider.name,
        provider.default_model,
    )
    return provider


async def ingest_knowledge(
    db: AsyncSession,
    *,
    owner_id: str,
    title: str,
    content: str,
    source_type: str = "manual",
    source_uri: Optional[str] = None,
    project_id: Optional[str] = None,
) -> KnowledgeItem:
    """
    Ingest one knowledge item: persist, chunk, embed, mark ready.

    Embedding failure marks the item `failed` with the error recorded in
    metadata — never a silent success.
    """
    item = KnowledgeItem(
        owner_id=owner_id,
        project_id=project_id,
        title=title.strip(),
        source_type=source_type,
        source_uri=source_uri,
        content_hash=hashlib.sha256(content.encode("utf-8")).hexdigest(),
        status="processing",
        meta={"content_chars": len(content)},
    )
    db.add(item)
    await db.flush()

    chunks = chunk_text(content)
    if not chunks:
        item.status = "failed"
        item.meta = {**item.meta, "error": "No content to index"}
        await db.flush()
        return item

    provider = get_embedding_provider()
    try:
        response = await provider.embed([c.content for c in chunks])
    except Exception as exc:  # ProviderError et al. — recorded, surfaced via status
        logger.error("embedding failed for knowledge item %s: %s", item.id, exc)
        item.status = "failed"
        item.meta = {**item.meta, "error": str(exc)}
        await db.flush()
        return item

    for chunk, vector in zip(chunks, response.vectors, strict=True):
        db.add(
            Embedding(
                knowledge_item_id=item.id,
                chunk_index=chunk.index,
                content=chunk.content,
                embedding=vector,
                meta={"model": response.model, "provider": response.provider},
            )
        )

    item.status = "ready"
    item.meta = {
        **item.meta,
        "chunk_count": len(chunks),
        "embedding_model": response.model,
        "embedding_provider": response.provider,
        "simulated_embeddings": response.provider == "mock",
    }
    await db.flush()
    await db.refresh(item)
    return item


async def search_knowledge(
    db: AsyncSession,
    *,
    owner_id: str,
    query: str,
    limit: int = 5,
    project_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Semantic search over the owner's ready knowledge.

    Returns ranked chunks with source attribution and cosine distance
    (lower = closer; exposed for transparency).
    """
    provider = get_embedding_provider()
    response = await provider.embed([query])
    query_vector = response.vectors[0]

    distance = Embedding.embedding.cosine_distance(query_vector).label("distance")
    stmt = (
        select(Embedding, KnowledgeItem, distance)
        .join(KnowledgeItem, KnowledgeItem.id == Embedding.knowledge_item_id)
        .where(
            KnowledgeItem.owner_id == owner_id,
            KnowledgeItem.status == "ready",
            Embedding.embedding.is_not(None),
        )
        .order_by(distance.asc())
        .limit(limit)
    )
    if project_id:
        stmt = stmt.where(KnowledgeItem.project_id == project_id)

    result = await db.execute(stmt)
    hits: List[Dict[str, Any]] = []
    for embedding, item, dist in result.all():
        hits.append(
            {
                "knowledge_item_id": item.id,
                "title": item.title,
                "source_type": item.source_type,
                "chunk_index": embedding.chunk_index,
                "content": embedding.content,
                "distance": round(float(dist), 4),
            }
        )
    return hits


async def retrieve_for_context(
    db: AsyncSession,
    *,
    owner_id: str,
    message: str,
    project_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Top-k knowledge chunks shaped for ContextPacket.retrieved_knowledge."""
    if not settings.RETRIEVAL_ENABLED:
        return []
    try:
        hits = await search_knowledge(
            db,
            owner_id=owner_id,
            query=message,
            limit=settings.RETRIEVAL_TOP_K,
            project_id=project_id,
        )
    except Exception as exc:  # retrieval must never take down a council run
        logger.error("knowledge retrieval failed (continuing without): %s", exc)
        return []
    return [
        {
            "source": hit["title"],
            "knowledge_item_id": hit["knowledge_item_id"],
            "chunk_index": hit["chunk_index"],
            "content": hit["content"],
            "distance": hit["distance"],
        }
        for hit in hits
    ]
