"""CLI entrypoints, invoked by cron or by an operator — never by the API."""
