"""
Workflow endpoints — automation with a human in front of every effect.

A workflow is a trigger plus an ordered list of steps. Steps that only read
(`knowledge_search`, `council`) run unattended. Steps that change state or
leave the system (`memory_write`, `decision_draft`, `export`) stop the run
until the owner approves them, every run, with no way to switch that off
through this API.

Route order matters here: `/step-types` is declared before `/{workflow_id}`,
or FastAPI would match it as a workflow id and 404.
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Query,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.session import get_db
from app.models.workflow import Workflow, WorkflowRun
from app.security.deps import CurrentUser
from app.services.dispatcher import compute_next_run_at
from app.services.workflows import (
    WorkflowStateError,
    describe_definition,
    parse_definition,
    resume_run,
    start_run,
)
from services.workflows import (
    EFFECT_STEP_TYPES,
    RunStatus,
    StepType,
    TriggerType,
    WorkflowDefinitionError,
)

router = APIRouter(prefix="/workflows", tags=["Workflows"])

_EDITABLE_STATUSES = {"draft", "active", "paused", "archived"}

#: Presentation metadata for the builder. Labels and descriptions are a UI
#: concern and live here; `requires_approval` is not — it is read from the
#: services layer so the interface can never claim a step is safe when the
#: engine treats it as an effect.
_STEP_CATALOG: Dict[StepType, Dict[str, str]] = {
    StepType.KNOWLEDGE_SEARCH: {
        "label": "Knowledge search",
        "description": "Retrieve stored material related to a query, with sources.",
        "required_config": "query",
    },
    StepType.COUNCIL: {
        "label": "Council run",
        "description": "Put a question to the Council and capture the synthesis.",
        "required_config": "prompt",
    },
    StepType.MEMORY_WRITE: {
        "label": "Memory write",
        "description": "Remember something for future runs. You approve the text.",
        "required_config": "content",
    },
    StepType.DECISION_DRAFT: {
        "label": "Draft a decision",
        "description": "Open a decision record. The call stays yours to make.",
        "required_config": "question",
    },
    StepType.EXPORT: {
        "label": "Prepare an export",
        "description": "Render a brief into the run record for you to read.",
        "required_config": "title",
    },
}


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class WorkflowCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=2000)
    definition: Dict[str, Any] = Field(default_factory=dict)
    project_id: Optional[str] = None


class WorkflowUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=2000)
    definition: Optional[Dict[str, Any]] = None
    status: Optional[str] = Field(None, pattern="^(draft|active|paused|archived)$")


class DefinitionSummary(BaseModel):
    valid: bool
    error: Optional[str] = None
    step_count: int
    approval_steps: List[str]
    trigger_type: Optional[str] = None
    awaiting_dispatcher: bool


class RunSummary(BaseModel):
    id: str
    status: str
    trigger: str
    pending_step_id: Optional[str] = None
    total_tokens: int
    started_at: datetime
    completed_at: Optional[datetime] = None


class WorkflowResponse(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    definition: Dict[str, Any]
    summary: DefinitionSummary
    status: str
    project_id: Optional[str] = None
    run_count: int = 0
    last_run: Optional[RunSummary] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    #: Set only for active workflows on a parseable schedule cadence.
    next_run_at: Optional[datetime] = None
    last_fired_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime


class StepResultResponse(BaseModel):
    step_id: str
    step_type: str
    status: str
    summary: str = ""
    text: str = ""
    data: Dict[str, Any] = Field(default_factory=dict)
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: int = 0
    error: Optional[str] = None


class PendingApproval(BaseModel):
    """Exactly what the owner is being asked to allow, already rendered."""

    step_id: str
    step_type: Optional[str] = None
    preview: Dict[str, Any] = Field(default_factory=dict)


class WorkflowRunResponse(BaseModel):
    id: str
    workflow_id: str
    workflow_name: str
    status: str
    trigger: str
    trigger_input: Optional[str] = None
    steps: List[StepResultResponse]
    approvals: Dict[str, Any] = Field(default_factory=dict)
    pending: Optional[PendingApproval] = None
    token_usage: Dict[str, int] = Field(default_factory=dict)
    latency_ms: int = 0
    error_message: Optional[str] = None
    started_at: datetime
    completed_at: Optional[datetime] = None


class RunRequest(BaseModel):
    input: str = Field("", max_length=20_000)


class ApprovalRequest(BaseModel):
    decisions: Dict[str, str] = Field(
        ...,
        description="`{step_id: 'approved' | 'rejected'}`. The step the run is "
        "paused in front of must be among them.",
    )


class StepTypeInfo(BaseModel):
    type: str
    label: str
    description: str
    required_config: str
    requires_approval: bool


class WorkflowCapabilities(BaseModel):
    step_types: List[StepTypeInfo]
    trigger_types: List[str]
    max_steps: int
    approval_required: bool
    #: Triggers the platform stores and validates but cannot yet fire on its
    #: own. Surfaced so the UI can say so instead of implying a scheduler.
    dispatchable_triggers: List[str]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run_summary(run: WorkflowRun) -> RunSummary:
    usage = run.token_usage or {}
    return RunSummary(
        id=run.id,
        status=run.status,
        trigger=run.trigger,
        pending_step_id=run.pending_step_id,
        total_tokens=int(usage.get("total_tokens") or 0),
        started_at=run.started_at,
        completed_at=run.completed_at,
    )


def _workflow_response(
    workflow: Workflow,
    *,
    run_count: int = 0,
    last_run: Optional[WorkflowRun] = None,
) -> WorkflowResponse:
    summary = describe_definition(workflow.definition)
    # Corrected here rather than in the services layer: as of 5.1 a scheduler
    # dispatches `schedule` triggers, so only `event` is still undispatched.
    # `WorkflowTrigger.awaiting_dispatcher` predates that and still reports
    # every non-manual trigger as waiting.
    summary["awaiting_dispatcher"] = summary.get("trigger_type") == "event"
    return WorkflowResponse(
        id=workflow.id,
        name=workflow.name,
        description=workflow.description,
        definition=workflow.definition or {},
        summary=DefinitionSummary(**summary),
        status=workflow.status,
        project_id=workflow.project_id,
        run_count=run_count,
        last_run=_run_summary(last_run) if last_run is not None else None,
        metadata=workflow.meta or {},
        next_run_at=workflow.next_run_at,
        last_fired_at=workflow.last_fired_at,
        created_at=workflow.created_at,
        updated_at=workflow.updated_at,
    )


def _pending_approval(run: WorkflowRun) -> Optional[PendingApproval]:
    """
    The rendered preview the engine emitted when it stopped. Reading it back
    from the recorded events means the gate shows the exact text that would be
    written — not the template, and not a re-render that could differ.
    """
    if run.status != RunStatus.AWAITING_APPROVAL or not run.pending_step_id:
        return None
    events = (run.meta or {}).get("events") or []
    for event in reversed(events):
        if (
            isinstance(event, dict)
            and event.get("type") == "awaiting_approval"
            and event.get("step_id") == run.pending_step_id
        ):
            return PendingApproval(
                step_id=run.pending_step_id,
                step_type=event.get("step_type"),
                preview=event.get("preview") or {},
            )
    return PendingApproval(step_id=run.pending_step_id)


def _run_response(run: WorkflowRun, workflow: Workflow) -> WorkflowRunResponse:
    return WorkflowRunResponse(
        id=run.id,
        workflow_id=run.workflow_id,
        workflow_name=workflow.name,
        status=run.status,
        trigger=run.trigger,
        trigger_input=run.trigger_input,
        steps=[StepResultResponse(**r) for r in (run.step_results or [])],
        approvals=run.approvals or {},
        pending=_pending_approval(run),
        token_usage=run.token_usage or {},
        latency_ms=int((run.meta or {}).get("latency_ms") or 0),
        error_message=run.error_message,
        started_at=run.started_at,
        completed_at=run.completed_at,
    )


async def _owned_workflow(
    workflow_id: str, user_id: str, db: AsyncSession
) -> Workflow:
    result = await db.execute(
        select(Workflow).where(
            Workflow.id == workflow_id, Workflow.owner_id == user_id
        )
    )
    workflow = result.scalar_one_or_none()
    if workflow is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found"
        )
    return workflow


async def _owned_run(
    workflow: Workflow, run_id: str, db: AsyncSession
) -> WorkflowRun:
    result = await db.execute(
        select(WorkflowRun).where(
            WorkflowRun.id == run_id, WorkflowRun.workflow_id == workflow.id
        )
    )
    run = result.scalar_one_or_none()
    if run is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Run not found"
        )
    return run


def _validated(raw: Any) -> Dict[str, Any]:
    """Definitions are validated at save time so runs never meet a bad one."""
    try:
        return parse_definition(raw).to_dict()
    except WorkflowDefinitionError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc


# ---------------------------------------------------------------------------
# Capabilities (declared before /{workflow_id})
# ---------------------------------------------------------------------------


@router.get("/step-types", response_model=WorkflowCapabilities)
async def list_step_types(current_user: CurrentUser):
    """
    What a workflow may contain, and which steps stop for approval.

    The builder reads this rather than hard-coding the step list, so a new
    step type never ships to the UI without its approval semantics.
    """
    return WorkflowCapabilities(
        step_types=[
            StepTypeInfo(
                type=step_type.value,
                requires_approval=step_type in EFFECT_STEP_TYPES,
                **_STEP_CATALOG[step_type],
            )
            for step_type in StepType
        ],
        trigger_types=[t.value for t in TriggerType],
        max_steps=settings.WORKFLOW_MAX_STEPS,
        approval_required=settings.WORKFLOW_APPROVAL_REQUIRED,
        dispatchable_triggers=[TriggerType.MANUAL.value, TriggerType.SCHEDULE.value],
    )


# ---------------------------------------------------------------------------
# Workflows
# ---------------------------------------------------------------------------


@router.get("", response_model=List[WorkflowResponse])
async def list_workflows(
    current_user: CurrentUser,
    status_filter: Optional[str] = Query(None, alias="status"),
    project_id: Optional[str] = None,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """The current user's workflows, most recently updated first."""
    stmt = (
        select(Workflow)
        .where(Workflow.owner_id == current_user.id)
        # `id` is the tiebreak, not decoration: two workflows saved in the
        # same transaction share an `updated_at`, and an unstable sort under
        # pagination silently drops and duplicates rows across pages.
        .order_by(Workflow.updated_at.desc(), Workflow.id)
        .limit(limit)
        .offset(offset)
    )
    if status_filter:
        stmt = stmt.where(Workflow.status == status_filter)
    if project_id:
        stmt = stmt.where(Workflow.project_id == project_id)

    workflows = list((await db.execute(stmt)).scalars().all())
    if not workflows:
        return []

    ids = [w.id for w in workflows]

    counts = dict(
        (
            await db.execute(
                select(WorkflowRun.workflow_id, func.count())
                .where(WorkflowRun.workflow_id.in_(ids))
                .group_by(WorkflowRun.workflow_id)
            )
        ).all()
    )
    # DISTINCT ON: one query for the newest run of every workflow, rather than
    # a per-row lookup that turns a 20-workflow list into 21 round trips.
    latest_rows = (
        await db.execute(
            select(WorkflowRun)
            .where(WorkflowRun.workflow_id.in_(ids))
            .order_by(WorkflowRun.workflow_id, WorkflowRun.started_at.desc())
            .distinct(WorkflowRun.workflow_id)
        )
    ).scalars()
    latest = {run.workflow_id: run for run in latest_rows}

    return [
        _workflow_response(
            w, run_count=int(counts.get(w.id, 0)), last_run=latest.get(w.id)
        )
        for w in workflows
    ]


@router.post("", response_model=WorkflowResponse, status_code=status.HTTP_201_CREATED)
async def create_workflow(
    payload: WorkflowCreate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Create a workflow. New workflows start as drafts and never auto-run."""
    definition = _validated(payload.definition or {})
    workflow = Workflow(
        owner_id=current_user.id,
        project_id=payload.project_id,
        name=payload.name.strip(),
        description=(payload.description or "").strip() or None,
        definition=definition,
        status="draft",
        meta={"origin": "manual"},
    )
    db.add(workflow)
    await db.flush()
    # Draft workflows are not dispatched, but the slot is computed now so the
    # UI can show when it *would* fire before anyone activates it.
    workflow.next_run_at = compute_next_run_at(
        workflow, now=datetime.now(timezone.utc)
    )
    await db.flush()
    await db.refresh(workflow)
    return _workflow_response(workflow)


@router.get("/{workflow_id}", response_model=WorkflowResponse)
async def get_workflow(
    workflow_id: str,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """One workflow, with its run count and most recent run."""
    workflow = await _owned_workflow(workflow_id, current_user.id, db)
    count = await db.scalar(
        select(func.count())
        .select_from(WorkflowRun)
        .where(WorkflowRun.workflow_id == workflow.id)
    )
    last_run = (
        await db.execute(
            select(WorkflowRun)
            .where(WorkflowRun.workflow_id == workflow.id)
            .order_by(WorkflowRun.started_at.desc())
            .limit(1)
        )
    ).scalar_one_or_none()
    return _workflow_response(workflow, run_count=int(count or 0), last_run=last_run)


@router.patch("/{workflow_id}", response_model=WorkflowResponse)
async def update_workflow(
    workflow_id: str,
    payload: WorkflowUpdate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """
    Update a workflow.

    Activation is guarded: a workflow with an invalid or empty definition
    cannot be set `active`, because "active" is a promise that it would do
    something if it fired.
    """
    workflow = await _owned_workflow(workflow_id, current_user.id, db)

    if payload.name is not None:
        workflow.name = payload.name.strip()
    if payload.description is not None:
        workflow.description = payload.description.strip() or None
    if payload.definition is not None:
        workflow.definition = _validated(payload.definition)
    if payload.status is not None:
        if payload.status not in _EDITABLE_STATUSES:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Unknown status {payload.status!r}",
            )
        if payload.status == "active":
            summary = describe_definition(workflow.definition)
            if not summary["valid"]:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Cannot activate: {summary['error']}",
                )
            if summary["step_count"] == 0:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Cannot activate a workflow with no steps",
                )
        workflow.status = payload.status

    # Recomputed on every save: an edited cadence must take effect now, not
    # at the next fire of the old schedule.
    workflow.next_run_at = compute_next_run_at(
        workflow, now=datetime.now(timezone.utc)
    )
    await db.flush()
    await db.refresh(workflow)
    return _workflow_response(workflow)


@router.delete("/{workflow_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_workflow(
    workflow_id: str,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """
    Delete a workflow and its run history.

    A run paused for approval is a question still open with the user, so
    deleting past it is refused — resolve or halt the run first.
    """
    workflow = await _owned_workflow(workflow_id, current_user.id, db)
    awaiting = await db.scalar(
        select(func.count())
        .select_from(WorkflowRun)
        .where(
            WorkflowRun.workflow_id == workflow.id,
            WorkflowRun.status == RunStatus.AWAITING_APPROVAL,
        )
    )
    if awaiting:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This workflow has a run waiting for your approval. "
            "Approve or reject it before deleting.",
        )
    await db.delete(workflow)
    await db.flush()


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------


@router.post(
    "/{workflow_id}/runs",
    response_model=WorkflowRunResponse,
    status_code=status.HTTP_201_CREATED,
)
async def run_workflow(
    workflow_id: str,
    payload: RunRequest,
    current_user: CurrentUser,
    response: Response,
    idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
    db: AsyncSession = Depends(get_db),
):
    """
    Start a run and advance it as far as it can go unattended.

    Returns `awaiting_approval` the moment it reaches an effect step — with
    the rendered preview attached — or a terminal status if it never does.

    Send an `Idempotency-Key` header to make the call safe to retry: a repeat
    of the same key on the same workflow returns the original run with `200`
    instead of starting a second one. Without it, a double-submitted
    read-only workflow really does run twice — the awaiting-gate guard below
    only catches the case where the first run stopped.
    """
    workflow = await _owned_workflow(workflow_id, current_user.id, db)

    if idempotency_key:
        replay = (
            await db.execute(
                select(WorkflowRun).where(
                    WorkflowRun.workflow_id == workflow.id,
                    WorkflowRun.meta["idempotency_key"].astext == idempotency_key,
                )
            )
        ).scalar_one_or_none()
        if replay is not None:
            response.status_code = status.HTTP_200_OK
            return _run_response(replay, workflow)

    # One open gate at a time. Concurrent paused runs would mean approving
    # them in an arbitrary order, and effect steps interpolate earlier
    # results — the outcome would depend on click order.
    blocking = (
        await db.execute(
            select(WorkflowRun)
            .where(
                WorkflowRun.workflow_id == workflow.id,
                WorkflowRun.status == RunStatus.AWAITING_APPROVAL,
            )
            .limit(1)
        )
    ).scalar_one_or_none()
    if blocking is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Run {blocking.id} is waiting on step "
            f"{blocking.pending_step_id!r}. Decide that one first.",
        )

    try:
        run = await start_run(
            db,
            workflow=workflow,
            user_id=current_user.id,
            trigger_input=payload.input,
        )
    except WorkflowDefinitionError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc
    except WorkflowStateError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail=str(exc)
        ) from exc

    if idempotency_key:
        # Merged, never replaced: the engine's event history lives here too,
        # and it is what the approval gate reads its preview back from.
        run.meta = {**(run.meta or {}), "idempotency_key": idempotency_key}
        await db.flush()

    return _run_response(run, workflow)


@router.get("/{workflow_id}/runs", response_model=List[WorkflowRunResponse])
async def list_runs(
    workflow_id: str,
    current_user: CurrentUser,
    limit: int = Query(default=0, ge=0, le=200),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """Run history for one workflow, newest first."""
    workflow = await _owned_workflow(workflow_id, current_user.id, db)
    runs = (
        await db.execute(
            select(WorkflowRun)
            .where(WorkflowRun.workflow_id == workflow.id)
            .order_by(WorkflowRun.started_at.desc(), WorkflowRun.id)
            .limit(limit or settings.WORKFLOW_RUN_HISTORY_LIMIT)
            .offset(offset)
        )
    ).scalars()
    return [_run_response(run, workflow) for run in runs]


@router.get("/{workflow_id}/runs/{run_id}", response_model=WorkflowRunResponse)
async def get_run(
    workflow_id: str,
    run_id: str,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """One run in full — every step result, approval, and token count."""
    workflow = await _owned_workflow(workflow_id, current_user.id, db)
    run = await _owned_run(workflow, run_id, db)
    return _run_response(run, workflow)


@router.post(
    "/{workflow_id}/runs/{run_id}/approve", response_model=WorkflowRunResponse
)
async def approve_run(
    workflow_id: str,
    run_id: str,
    payload: ApprovalRequest,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """
    Record approval decisions and continue the run.

    `approved` lets that step execute; `rejected` halts the run there and
    keeps everything up to it. Both are written into the run with the actor
    and the time — an approval is a signed act, not a flag.
    """
    workflow = await _owned_workflow(workflow_id, current_user.id, db)
    run = await _owned_run(workflow, run_id, db)
    try:
        resumed = await resume_run(
            db,
            workflow=workflow,
            run=run,
            decisions=payload.decisions,
            actor_id=current_user.id,
        )
    except WorkflowStateError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail=str(exc)
        ) from exc
    except WorkflowDefinitionError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc
    return _run_response(resumed, workflow)
