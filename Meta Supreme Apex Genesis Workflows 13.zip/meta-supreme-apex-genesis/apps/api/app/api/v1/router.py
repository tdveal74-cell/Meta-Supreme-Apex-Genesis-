"""
API v1 Router — aggregates all module routers.
"""

from fastapi import APIRouter

from app.api.v1 import (
    agents,
    auth,
    conversations,
    decisions,
    health,
    intelligence,
    knowledge,
    memory,
    projects,
    workflows,
)

api_router = APIRouter()

api_router.include_router(health.router, tags=["Health"])
api_router.include_router(auth.router)
api_router.include_router(projects.router)
api_router.include_router(agents.router)
api_router.include_router(conversations.router)
api_router.include_router(intelligence.router)
api_router.include_router(knowledge.router)
api_router.include_router(memory.router)
api_router.include_router(decisions.router)
api_router.include_router(workflows.router)

# Future modules (Phase 6+)
# api_router.include_router(users.router, prefix="/users", tags=["Users"])
# api_router.include_router(feedback.router, prefix="/feedback", tags=["Feedback"])
# api_router.include_router(admin.router, prefix="/admin", tags=["Administration"])
