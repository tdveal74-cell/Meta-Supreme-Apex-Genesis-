# Meta Supreme Apex Genesis — API

FastAPI backend for the Intelligence Operating System.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

- Health: `GET /api/v1/health`
- Docs: http://localhost:8000/api/docs

## Structure

- `app/main.py` — application entry
- `app/api/v1/` — versioned routes
- `app/core/` — config & logging
- `app/models/` — SQLAlchemy / domain models (Phase 1+)
- `app/services/` — business logic
- `app/security/` — auth, RBAC, encryption
- `app/agents/` — local agent execution helpers
