# Meta Supreme Apex Genesis

**Intelligence Operating System**

> Amplify human decision-making and execution through multi-agent AI reasoning, knowledge management, long-term memory, decision intelligence, and workflow automation.

Meta Supreme Apex Genesis is a scalable SaaS intelligence platform designed for individuals and organizations who need to think clearly, make better decisions, organize knowledge, automate repetitive work, and navigate complexity.

This is not a chatbot.  
This is an **intelligence operating system**.

---

## Core Vision

| Humans Provide | AI Provides |
|----------------|-------------|
| Judgment       | Analysis    |
| Values         | Patterns    |
| Responsibility | Recommendations |
| Final decisions| Execution support |

The system exists to create **strategic leverage** while keeping humans in control.

---

## Architecture Overview

```
USER EXPERIENCE
      ▼
APPLICATION LAYER
      ▼
API SERVICES
      ▼
INTELLIGENCE ORCHESTRATION ENGINE
      ▼
AI COUNCIL SYSTEM
      ▼
KNOWLEDGE ENGINE
      ▼
MEMORY ENGINE
      ▼
DATABASE
      ▼
INFRASTRUCTURE
```

### Key Subsystems

- **Executive Controller** — Intent understanding, context retrieval, agent routing, synthesis
- **AI Council** — Specialized agents (Oracle, Analyst, Strategist, Architect, Engineer, Guardian, Creator, Librarian, Skeptic)
- **Knowledge Engine** — Document ingestion, chunking, embeddings, semantic retrieval
- **Memory Engine** — Persistent, transparent, editable long-term memory
- **Decision Center** — Structured decision tracking and outcome learning

---

## Technology Stack

| Layer        | Technology                          |
|--------------|-------------------------------------|
| Frontend     | Next.js, React, TypeScript, Tailwind CSS, shadcn/ui, Framer Motion |
| Backend      | Python, FastAPI                     |
| Database     | PostgreSQL + pgvector               |
| Auth         | Supabase-compatible / custom JWT    |
| Infrastructure | Docker, CI/CD, Cloud-ready        |

**Design System**
- Primary: Deep Navy `#0A1628`
- Accent: Amber Gold `#D4A017`
- Surface: Warm Off-White

---

## Repository Structure

```
meta-supreme-apex-genesis/
├── apps/
│   ├── web/                 # Next.js frontend
│   └── api/                 # FastAPI backend (alternative entry)
├── services/
│   ├── intelligence/        # Executive Controller + orchestration
│   ├── agents/              # AI Council agents
│   ├── knowledge/           # Knowledge Engine
│   └── memory/              # Memory Engine
├── packages/
│   ├── ui/                  # Shared UI components
│   ├── shared/              # Shared utilities
│   └── types/               # Shared TypeScript / Pydantic types
├── database/
│   ├── migrations/          # SQL / Alembic migrations
│   └── schemas/             # Schema definitions
├── docs/
│   ├── architecture/        # Deep architecture docs
│   ├── api/                 # API reference
│   └── guides/              # Developer & user guides
├── infrastructure/
│   ├── docker/              # Dockerfiles & compose
│   ├── ci/                  # GitHub Actions / CI pipelines
│   ├── k8s/                 # Kubernetes manifests
│   └── terraform/           # Infrastructure as Code
├── ARCHITECTURE.md
├── CONTRIBUTING.md
├── CHANGELOG.md
└── README.md
```

---

## Getting Started (Development)

### Prerequisites

- Node.js 20+
- Python 3.11+
- Docker & Docker Compose
- PostgreSQL 16+ with pgvector
- pnpm (recommended) or npm

### Quick Start

```bash
# Clone
git clone <repo-url>
cd meta-supreme-apex-genesis

# Install frontend + backend dependencies
make install

# Start full stack (PostgreSQL + API + Web)
make up

# Or run services individually
make api    # FastAPI → http://localhost:8000
make web    # Next.js  → http://localhost:3000
```

- Frontend: http://localhost:3000  
- API docs:  http://localhost:8000/api/docs  
- Health:    http://localhost:8000/api/v1/health  

See `docs/guides/getting-started.md` and `Makefile` for more commands.

---

## Build Phases

| Phase | Focus                      | Status     |
|-------|----------------------------|------------|
| 1     | Foundation (Repo, Shell, Auth, DB) | Complete   |
| 2     | Intelligence Core          | Complete   |
| 3     | Knowledge System           | Complete   |
| 4     | Council System             | **Complete** |
| 5     | Product Layer              | Partial (Memory + Decisions delivered; Workflows next) |
| 6     | SaaS Layer                 | Pending    |
| 7     | Enterprise Layer           | Pending    |

---

## Engineering Principles

- **Secure by design**
- **Transparent by default**
- **Modular by architecture**
- **Simple by experience**
- **Powerful beneath the surface**

Never hard-code secrets.  
Never create temporary systems without migration paths.  
Always protect user data.  
Always maintain modularity.

---

## License

Proprietary — All rights reserved.  
See [LICENSE](./LICENSE) for details.

---

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for coding standards, branch strategy, and PR process.

---

**Meta Supreme Apex Genesis**  
*The intelligence operating system.*
